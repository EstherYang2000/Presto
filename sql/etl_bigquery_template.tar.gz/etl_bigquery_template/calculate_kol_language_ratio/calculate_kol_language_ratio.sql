/*
- Target: 計算 kol_id 近一年在三平台（ig/fb/yt）的貼文語言比例
- Source: renata_rawdata_all.ml_post_text_lang_id,
          renata_rawdata_all.latest_instagram_post,
          renata_rawdata_all.latest_facebook_post,
          renata_rawdata_all.latest_youtube_post,
          renata_rawdata_all.kol_url
- Description:
  1. 取得近一年三平台（ig/fb/yt）帳號的貼文語言
  2. 計算各 kol_id 的貼文語言比例
*/
DECLARE end_date DATETIME DEFAULT(CURRENT_DATE());
DECLARE start_date DATETIME;

SET start_date = (
    SELECT DATETIME_SUB(end_date, INTERVAL 12 MONTH)
);

DROP TABLE IF EXISTS `renata_feature.kol_language_ratio_latest`;
CREATE TABLE IF NOT EXISTS `renata_feature.kol_language_ratio_latest` AS (

WITH
    post_lang AS (
        SELECT 
            platform,
            post_id,
            REPLACE(JSON_EXTRACT(model_output, '$.language'), '"', '') AS lang
        FROM `renata_rawdata_all.ml_post_text_lang_id`
        WHERE (post_time BETWEEN TIMESTAMP(start_date) AND TIMESTAMP(end_date))
    ),
    user_lang AS (
        SELECT
            post.platform,
            post.platform_user_id,
            post.platform_post_id,
            post_lang.lang
        FROM `renata_rawdata_all.latest_instagram_post` AS post
        LEFT JOIN post_lang
            ON post.platform_post_id = post_lang.post_id
        WHERE post_time BETWEEN TIMESTAMP(start_date) AND TIMESTAMP(end_date)

        UNION ALL

        SELECT
            post.platform,
            post.platform_user_id,
            post.platform_post_id,
            post_lang.lang
        FROM `renata_rawdata_all.latest_facebook_post` AS post
        LEFT JOIN post_lang
            ON post.platform_post_id = post_lang.post_id
        WHERE post_time BETWEEN TIMESTAMP(start_date) AND TIMESTAMP(end_date)

        UNION ALL

        SELECT
            post.platform,
            post.platform_user_id,
            post.platform_post_id,
            post_lang.lang
        FROM `renata_rawdata_all.latest_youtube_post` AS post
        LEFT JOIN post_lang
            ON post.platform_post_id = post_lang.post_id
        WHERE post_time BETWEEN TIMESTAMP(start_date) AND TIMESTAMP(end_date)
    )

SELECT DISTINCT
    url.kol_id,
    IF(lang = '<unk>', 'unknown', lang) AS language,
    COUNT(DISTINCT IF(user_lang.platform = 'ig', platform_post_id, NULL)) OVER(PARTITION BY url.kol_id, lang) AS lang_ig_post_cnt,
    COUNT(DISTINCT IF(user_lang.platform = 'fb', platform_post_id, NULL)) OVER(PARTITION BY url.kol_id, lang) AS lang_fb_post_cnt,
    COUNT(DISTINCT IF(user_lang.platform = 'yt', platform_post_id, NULL)) OVER(PARTITION BY url.kol_id, lang) AS lang_yt_post_cnt,
    COUNT(DISTINCT platform_post_id) OVER(PARTITION BY url.kol_id, lang) AS lang_all_post_cnt,
    SAFE_DIVIDE(
        COUNT(DISTINCT platform_post_id) OVER(PARTITION BY url.kol_id, lang) * 100, 
        COUNT(DISTINCT platform_post_id) OVER(PARTITION BY url.kol_id)
    ) AS lang_ratio,
    DATE(end_date) AS calculated_end_date,
    CURRENT_TIMESTAMP() AS etl_at
FROM user_lang
LEFT JOIN `renata_rawdata_all.kol_url` AS url
    ON user_lang.platform = url.platform
        AND user_lang.platform_user_id = url.platform_user_id
WHERE url.kol_id IS NOT NULL AND lang IS NOT NULL
ORDER BY kol_id, lang_ratio DESC

);

CREATE TABLE IF NOT EXISTS `renata_feature.kol_language_ratio_hist` (
    kol_id INT64,
    language STRING,
    lang_ig_post_cnt INT64,
    lang_fb_post_cnt INT64,
    lang_yt_post_cnt INT64,
    lang_all_post_cnt INT64,
    lang_ratio FLOAT64,
    calculated_end_date DATE,
    etl_at TIMESTAMP
)
PARTITION BY calculated_end_date;

INSERT INTO `renata_feature.kol_language_ratio_hist`
SELECT * FROM `renata_feature.kol_language_ratio_latest`;

