/*
- Target: 產出 AI War Room 資料概況及最近一週熱度趨勢 Hashtags 的資料表
- Source: feature.multiplatform_posts,
          feature.profile_data_processed,
          renata_rawdata_all.latest_instagram_post,
          renata_rawdata_all.latest_facebook_post,
          renata_rawdata_all.latest_youtube_post,
          renata_rawdata_all.kol_url,
          renata_rawdata_all.kol,
          renata_rawdata_all.country,
          renata_ds_report_dashboard.hotness_and_trending_analysis_hotness_table,
          renata_ds_report_dashboard.hotness_and_trending_analysis_week_hashtags
- Description:
  1. KOL Overview: 產出 kol 的資料概況
  2. Posts Overview: 產出貼文的資料概況
  3. KOL URL Overview: 產出 kol_url 的資料概況
  4. Hashtag hotness & trending: 產出最近一週熱度趨勢 Hashtags
*/
DECLARE target_week_num INT64;
SET target_week_num = (
    SELECT
        CASE
            WHEN EXTRACT(week from CURRENT_DATE()) = 0
            THEN EXTRACT(year from CURRENT_DATE()) *100 + EXTRACT(week from CURRENT_DATE()) + 1
            ELSE EXTRACT(year from CURRENT_DATE()) *100 + EXTRACT(week from CURRENT_DATE())
        END
);

-- KOL Overview
DROP TABLE IF EXISTS `renata_ds_report_dashboard.ai_war_room_overview_kol`;
CREATE TABLE IF NOT EXISTS `renata_ds_report_dashboard.ai_war_room_overview_kol` AS(
SELECT
    kol.id,
    DATETIME(kol.created_time, 'Asia/Taipei') AS created_time,
    FORMAT_DATETIME('%Y%m', DATETIME(kol.created_time, 'Asia/Taipei')) AS created_month,
    CASE
        WHEN country.name_tw IS NOT NULL
        THEN country.name_tw
        ELSE '空標'
    END AS country,
    CASE
        WHEN DATE(created_time, 'Asia/Taipei') BETWEEN DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 MONTH) AND DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 DAY)
        THEN 1
        ELSE 0
    END AS last_month_ind,
    CASE
        WHEN DATE(created_time, 'Asia/Taipei') BETWEEN DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 2 MONTH) AND DATE_SUB(DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 MONTH), interval 1 DAY)
        THEN 1
        ELSE 0
    END AS lag_last_month_ind,
    CASE
        WHEN DATE(created_time, 'Asia/Taipei') BETWEEN DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), YEAR) AND DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 DAY)
        THEN 1
        ELSE 0
    END AS this_year_to_date_ind,
    CASE
        WHEN DATE(created_time, 'Asia/Taipei') BETWEEN DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), YEAR), interval 1 YEAR) AND DATE_SUB(DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 DAY), interval 1 YEAR)
        THEN 1
        ELSE 0
    END AS last_year_to_date_ind,
    CASE
        WHEN DATE(created_time, 'Asia/Taipei') <= DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 DAY)
        THEN 1
        ELSE 0
    END AS till_last_month_ind,
    FORMAT_DATETIME('%Y%m', DATETIME_SUB(DATETIME_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), INTERVAL 1 MONTH)) AS last_month,
    CURRENT_DATE('Asia/Taipei') AS table_updated_at
FROM `renata_rawdata_all.kol` AS kol
LEFT JOIN `renata_rawdata_all.country` AS country
ON kol.country_id = country.id
ORDER BY created_month
);

-- Posts Overview
DROP TABLE IF EXISTS `renata_ds_report_dashboard.ai_war_room_overview_posts`;
CREATE TABLE IF NOT EXISTS `renata_ds_report_dashboard.ai_war_room_overview_posts` 
PARTITION BY DATE(post_time) AS(
WITH
    all_posts AS(
        -- multiplatform_posts (post_time < 2022-11-01)
        SELECT
            post.platform,
            post_id AS platform_post_id,
            post_time,
            FORMAT_DATETIME('%Y%m', DATETIME(post_time, 'Asia/Taipei')) AS posted_month,
            CASE
                WHEN kol.country IS NOT NULL
                THEN kol.country
                ELSE '空標'
            END AS country,
        FROM `feature.multiplatform_posts` AS post
        LEFT JOIN `feature.profile_data_processed` AS kol
            ON post.kol_id = kol.kol_id
        WHERE DATE(post.post_time, 'Asia/Taipei') < '2022-11-01'

        UNION ALL

        -- latest_platform_post (post_time >= 2022-11-01)
        SELECT
            post.platform,
            platform_post_id,
            post_time,
            FORMAT_DATETIME('%Y%m', DATETIME(post_time, 'Asia/Taipei')) AS posted_month,
            CASE
                WHEN country.name_tw IS NOT NULL
                THEN country.name_tw
                ELSE '空標'
            END AS country,
        FROM `renata_rawdata_all.latest_instagram_post` AS post
        LEFT JOIN `renata_rawdata_all.kol_url` AS url
            ON post.platform = url.platform
            AND post.platform_user_id = url.platform_user_id
        INNER JOIN `renata_rawdata_all.kol` AS kol
            ON url.kol_id = kol.id
        LEFT JOIN `renata_rawdata_all.country` AS country
            ON kol.country_id = country.id
        WHERE DATE(post.post_time, 'Asia/Taipei') >= '2022-11-01'

        UNION ALL

        SELECT
            post.platform,
            platform_post_id,
            post_time,
            FORMAT_DATETIME('%Y%m', DATETIME(post_time, 'Asia/Taipei')) AS posted_month,
            CASE
                WHEN country.name_tw IS NOT NULL
                THEN country.name_tw
                ELSE '空標'
            END AS country,
        FROM `renata_rawdata_all.latest_facebook_post` AS post
        LEFT JOIN `renata_rawdata_all.kol_url` AS url
            ON post.platform = url.platform
            AND post.platform_user_id = url.platform_user_id
        INNER JOIN `renata_rawdata_all.kol` AS kol
            ON url.kol_id = kol.id
        LEFT JOIN `renata_rawdata_all.country` AS country
            ON kol.country_id = country.id
        WHERE DATE(post.post_time, 'Asia/Taipei') >= '2022-11-01'

        UNION ALL

        SELECT
            post.platform,
            platform_post_id,
            post_time,
            FORMAT_DATETIME('%Y%m', DATETIME(post_time, 'Asia/Taipei')) AS posted_month,
            CASE
                WHEN country.name_tw IS NOT NULL
                THEN country.name_tw
                ELSE '空標'
            END AS country,
        FROM `renata_rawdata_all.latest_youtube_post` AS post
        LEFT JOIN `renata_rawdata_all.kol_url` AS url
            ON post.platform = url.platform
            AND post.platform_user_id = url.platform_user_id
        INNER JOIN `renata_rawdata_all.kol` AS kol
            ON url.kol_id = kol.id
        LEFT JOIN `renata_rawdata_all.country` AS country
            ON kol.country_id = country.id
        WHERE DATE(post.post_time, 'Asia/Taipei') >= '2022-11-01'
    )

SELECT
    *,
    CASE
        WHEN DATE(post_time, 'Asia/Taipei') BETWEEN DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 MONTH) AND DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 DAY)  
        THEN 1
        ELSE 0
    END AS last_month_ind,
    CASE
        WHEN DATE(post_time, 'Asia/Taipei') BETWEEN DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 2 MONTH) AND DATE_SUB(DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 MONTH), interval 1 DAY) 
        THEN 1
        ELSE 0
    END AS lag_last_month_ind,
    CASE
        WHEN DATE(post_time, 'Asia/Taipei') <= DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 DAY)
        THEN 1
        ELSE 0
    END AS till_last_month_ind,
    CASE
        WHEN DATE(post_time, 'Asia/Taipei') BETWEEN DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), YEAR) AND DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 DAY)
        THEN 1
        ELSE 0
    END AS this_year_to_date_ind,
    CASE
        WHEN DATE(post_time, 'Asia/Taipei') BETWEEN DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), YEAR), interval 1 YEAR) AND DATE_SUB(DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 DAY), interval 1 YEAR)
        THEN 1
        ELSE 0
    END AS last_year_to_date_ind,
    CURRENT_DATE('Asia/Taipei') AS table_updated_at
FROM all_posts
);

-- KOL URL Overview
DROP TABLE IF EXISTS `renata_ds_report_dashboard.ai_war_room_overview_kol_url`;
CREATE TABLE IF NOT EXISTS `renata_ds_report_dashboard.ai_war_room_overview_kol_url` AS(
SELECT DISTINCT
    url.platform_user_id,
    url.status,
    DATETIME(url.created_time, 'Asia/Taipei') AS created_time,
    FORMAT_DATETIME('%Y%m', DATETIME(url.created_time, 'Asia/Taipei')) AS created_month,
    CASE
        WHEN url_country.name_tw IS NOT NULL
        THEN url_country.name_tw
        ELSE '空標'
    END AS url_country,
    CASE
        WHEN DATE(url.created_time, 'Asia/Taipei') BETWEEN DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 MONTH) AND DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 DAY)
        THEN 1
        ELSE 0
    END AS last_month_ind,
    CASE
        WHEN DATE(url.created_time, 'Asia/Taipei') BETWEEN DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 2 MONTH) AND DATE_SUB(DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 MONTH), interval 1 DAY)
        THEN 1
        ELSE 0
    END AS lag_last_month_ind,
    CASE
        WHEN DATE(url.created_time, 'Asia/Taipei') BETWEEN DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), YEAR) AND DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 DAY)
        THEN 1
        ELSE 0
    END AS this_year_to_date_ind,
    CASE
        WHEN DATE(url.created_time, 'Asia/Taipei') BETWEEN DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), YEAR), interval 1 YEAR) AND DATE_SUB(DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 DAY), interval 1 YEAR)
        THEN 1
        ELSE 0
    END AS last_year_to_date_ind,
    CASE
        WHEN DATE(url.created_time, 'Asia/Taipei') <= DATE_SUB(DATE_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), interval 1 DAY)
        THEN 1
        ELSE 0
    END AS till_last_month_ind,
    FORMAT_DATETIME('%Y%m', DATETIME_SUB(DATETIME_TRUNC(CURRENT_DATE('Asia/Taipei'), MONTH), INTERVAL 1 MONTH)) AS last_month,
    CURRENT_DATE('Asia/Taipei') AS table_updated_at
FROM `renata_rawdata_all.kol_url` AS url
LEFT JOIN `renata_rawdata_all.country` AS url_country
    ON url.country_id = url_country.id
WHERE platform_user_id IS NOT NULL AND platform_user_id != ''
ORDER BY created_month
);

-- Hashtag hotness & trending
DROP TABLE IF EXISTS `renata_ds_report_dashboard.ai_war_room_overview_trending_hashtag`;
CREATE TABLE IF NOT EXISTS `renata_ds_report_dashboard.ai_war_room_overview_trending_hashtag` AS(
WITH
  newest_result AS(
    SELECT 
        *
    FROM (
        SELECT
            hashtags,
            'ig' AS platform,
            autotag_tag_name,
            post_week,
            idx,
            weekly_voice_ig_t1 AS weekly_voice_t1,
            weekly_kol_cnt_ig_t1 AS weekly_kol_cnt_t1,
            nonlinear_index_ig_t1 AS nonlinear_index_t1,
            weekly_voice_ig_t0 AS weekly_voice_t0,
            weekly_kol_cnt_ig_t0 AS weekly_kol_cnt_t0,
            nonlinear_index_ig_t0 AS nonlinear_index_t0,
            nonlinear_PR_ig AS nonlinear_PR,
            growth_diff_MA_4week_ig AS growth_diff_MA_4week,
            can_score_ig AS can_score,
            is_new_ig AS is_new,
            hotness_autotag_rank_ig AS hotness_autotag_rank,
            hotness_rank_ig AS hotness_rank,
            trending_autotag_rank_ig AS trending_autotag_rank,
            trending_rank_ig AS trending_rank,
            table_updated_date
        FROM `renata_ds_report_dashboard.hotness_and_trending_analysis_hotness_table`
        UNION ALL 
        SELECT
            hashtags,
            'fb' AS platform,
            autotag_tag_name,
            post_week,
            idx,
            weekly_voice_fb_t1 AS weekly_voice_t1,
            weekly_kol_cnt_fb_t1 AS weekly_kol_cnt_t1,
            nonlinear_index_fb_t1 AS nonlinear_index_t1,
            weekly_voice_fb_t0 AS weekly_voice_t0,
            weekly_kol_cnt_fb_t0 AS weekly_kol_cnt_t0,
            nonlinear_index_fb_t0 AS nonlinear_index_t0,
            nonlinear_PR_fb AS nonlinear_PR,
            growth_diff_MA_4week_fb AS growth_diff_MA_4week,
            can_score_fb AS can_score,
            is_new_fb AS is_new,
            hotness_autotag_rank_fb AS hotness_autotag_rank,
            hotness_rank_fb AS hotness_rank,
            trending_autotag_rank_fb AS trending_autotag_rank,
            trending_rank_fb AS trending_rank,
            table_updated_date
        FROM `renata_ds_report_dashboard.hotness_and_trending_analysis_hotness_table`
    )
    WHERE post_week = (
        SELECT
            CAST(MAX(CAST(post_week AS INT64)) AS STRING)
        FROM `renata_ds_report_dashboard.hotness_and_trending_analysis_hotness_table`
        WHERE CAST(post_week AS INT64) <= target_week_num
        )
    
  ),
  newest_hashtag_posts AS(
    SELECT
        platform,
        autotag_tag_name,
        hashtags,
        url AS post_url,
        name AS kol_name,
        post_week,
        voice
    FROM `renata_ds_report_dashboard.hotness_and_trending_analysis_week_hashtags`
  )

SELECT
    res.*,
    CONCAT(SUBSTR(res.post_week, 1, 4), '年', SUBSTR(res.post_week, 5, 2), '週') AS post_week_str,
    post.post_url,
    post.voice AS post_voice,
    post.kol_name
FROM newest_result AS res
LEFT JOIN newest_hashtag_posts AS post
    ON res.autotag_tag_name = post.autotag_tag_name
        AND res.hashtags = post.hashtags
        AND res.platform = post.platform
        AND res.post_week = post.post_week
);