/*
- Target: 整理各平台近 200 天的貼文資訊
- Source: renata_rawdata_all.kol_followers,
          renata_rawdata_all.latest_facebook_post,
          renata_rawdata_all.latest_instagram_post,
          renata_rawdata_all.latest_youtube_post,
          renata_rawdata_all.kol_url,
          renata_rawdata_all.kol_followers,
          renata_rawdata_all.ml_text_sponsor,
- Description:
  1. 取得各個平台貼文資訊
*/

DECLARE current_dt DATETIME DEFAULT(DATE_TRUNC(CURRENT_DATETIME(), month));

DROP TABLE IF EXISTS renata_etl_temp.group_indicators_post_info;
CREATE TABLE renata_etl_temp.group_indicators_post_info AS
(
    WITH
        edge_followers AS (
            SELECT 
                kol_id,
                platform_user_id,
                platform,
                follower_count_processed,
                week_num,
                ROW_NUMBER() OVER (PARTITION BY kol_id, platform, platform_user_id ORDER BY week_num DESC) AS row_num_desc,
                ROW_NUMBER() OVER (PARTITION BY kol_id, platform, platform_user_id ORDER BY week_num ASC) AS row_num_asc
            FROM `renata_rawdata_all.kol_followers`
            WHERE follower_count_processed > 0
                AND platform_user_id <> 'undefined'
        )
    SELECT
        kol_url.kol_id,
        post.platform,
        post.platform_post_id,
        post.platform_user_id,
        DATE(post.post_time) AS post_date,
        CASE
            WHEN EXTRACT(week from post.post_time) = 0
            THEN EXTRACT(year from post.post_time) *100 + EXTRACT(week from post.post_time) + 1
            ELSE EXTRACT(year from post.post_time) *100 + EXTRACT(week from post.post_time)
        END AS week_num,
        post.is_video,
        post.is_live,
        FALSE AS is_short,
        post.like_count,
        post.comment_count,
        post.share_count,
        post.view_count,
        NULL AS play_count,
        CASE 
            WHEN sponsor.model_output = 'true'
            THEN TRUE
            WHEN sponsor.model_output = 'false'
            THEN FALSE
            ELSE NULL
        END is_sponsor,
        COALESCE(
            followers.follower_count_processed,
            FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY post.platform_user_id
                                                                                                ORDER BY post.post_time
                                                                                                ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
                                                                                        ),
            FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY post.platform_user_id
                                                                                                ORDER BY post.post_time
                                                                                                ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                                                                                        ),
            asc_followers.follower_count_processed
        ) AS follower_count
    FROM renata_rawdata_all.latest_facebook_post AS post
    INNER JOIN renata_rawdata_all.kol_url AS kol_url
        ON post.platform_user_id = kol_url.platform_user_id
            AND kol_url.platform = 'fb'
    LEFT JOIN `renata_rawdata_all.kol_followers` AS followers
        ON post.platform_user_id = followers.platform_user_id
            AND post.platform = followers.platform
            AND kol_url.kol_id = followers.kol_id
            AND (
                CASE
                    WHEN EXTRACT(week from post.post_time) = 0
                    THEN EXTRACT(year from post.post_time) *100 + EXTRACT(week from post.post_time) + 1
                    ELSE EXTRACT(year from post.post_time) *100 + EXTRACT(week from post.post_time)
                END
            ) = followers.week_num
    LEFT JOIN edge_followers AS asc_followers
        ON post.platform_user_id = asc_followers.platform_user_id
            AND post.platform = asc_followers.platform
            AND kol_url.kol_id = asc_followers.kol_id
            AND asc_followers.row_num_asc = 1
    LEFT JOIN renata_rawdata_all.ml_text_sponsor AS sponsor
        ON sponsor.post_id = post.platform_post_id
    WHERE post.post_time BETWEEN TIMESTAMP(DATETIME_SUB(current_dt, INTERVAL 180 DAY)) AND TIMESTAMP(current_dt)

    UNION ALL

    SELECT
        kol_url.kol_id,
        post.platform,
        post.platform_post_id,
        post.platform_user_id,
        DATE(post.post_time) AS post_date,
        CASE
            WHEN EXTRACT(week from post.post_time) = 0
            THEN EXTRACT(year from post.post_time) *100 + EXTRACT(week from post.post_time) + 1
            ELSE EXTRACT(year from post.post_time) *100 + EXTRACT(week from post.post_time)
        END AS week_num,
        post.is_video,
        post.is_live,
        post.is_short,
        post.like_count,
        post.comment_count,
        post.share_count,
        post.view_count,
        post.play_count,
        CASE 
            WHEN sponsor.model_output = 'true'
            THEN TRUE
            WHEN sponsor.model_output = 'false'
            THEN FALSE
            ELSE NULL
        END is_sponsor,
        COALESCE(
            followers.follower_count_processed,
            FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY post.platform_user_id
                                                                                                ORDER BY post.post_time
                                                                                                ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
                                                                                        ),
            FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY post.platform_user_id
                                                                                                ORDER BY post.post_time
                                                                                                ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                                                                                        ),
            asc_followers.follower_count_processed
        ) AS follower_count
    FROM renata_rawdata_all.latest_instagram_post AS post
    INNER JOIN renata_rawdata_all.kol_url AS kol_url
        ON post.platform_user_id = kol_url.platform_user_id
            AND kol_url.platform = 'ig'
    LEFT JOIN `renata_rawdata_all.kol_followers` AS followers
        ON post.platform_user_id = followers.platform_user_id
            AND post.platform = followers.platform
            AND kol_url.kol_id = followers.kol_id
            AND (
                CASE
                    WHEN EXTRACT(week from post.post_time) = 0
                    THEN EXTRACT(year from post.post_time) *100 + EXTRACT(week from post.post_time) + 1
                    ELSE EXTRACT(year from post.post_time) *100 + EXTRACT(week from post.post_time)
                END
            ) = followers.week_num
    LEFT JOIN edge_followers AS asc_followers
        ON post.platform_user_id = asc_followers.platform_user_id
            AND post.platform = asc_followers.platform
            AND kol_url.kol_id = asc_followers.kol_id
            AND asc_followers.row_num_asc = 1
    LEFT JOIN renata_rawdata_all.ml_text_sponsor AS sponsor
        ON sponsor.post_id = post.platform_post_id
    WHERE post.post_time BETWEEN TIMESTAMP(DATETIME_SUB(current_dt, INTERVAL 180 DAY)) AND TIMESTAMP(current_dt)

    UNION ALL

    SELECT
        kol_url.kol_id,
        post.platform,
        post.platform_post_id,
        post.platform_user_id,
        DATE(post.post_time) AS post_date,
        CASE
            WHEN EXTRACT(week from post.post_time) = 0
            THEN EXTRACT(year from post.post_time) *100 + EXTRACT(week from post.post_time) + 1
            ELSE EXTRACT(year from post.post_time) *100 + EXTRACT(week from post.post_time)
        END AS week_num,
        post.is_video,
        post.is_live,
        post.is_short,
        post.like_count,
        post.comment_count,
        post.share_count,
        post.view_count,
        NULL AS play_count,
        CASE 
            WHEN sponsor.model_output = 'true'
            THEN TRUE
            WHEN sponsor.model_output = 'false'
            THEN FALSE
            ELSE NULL
        END is_sponsor,
        COALESCE(
            followers.follower_count_processed,
            FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY post.platform_user_id
                                                                                                ORDER BY post.post_time
                                                                                                ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
                                                                                        ),
            FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY post.platform_user_id
                                                                                                ORDER BY post.post_time
                                                                                                ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                                                                                        ),
            asc_followers.follower_count_processed
        ) AS follower_count
    FROM renata_rawdata_all.latest_youtube_post AS post
    INNER JOIN renata_rawdata_all.kol_url AS kol_url
        ON post.platform_user_id = kol_url.platform_user_id
            AND kol_url.platform = 'yt'
    LEFT JOIN `renata_rawdata_all.kol_followers` AS followers
        ON post.platform_user_id = followers.platform_user_id
            AND post.platform = followers.platform
            AND kol_url.kol_id = followers.kol_id
            AND (
                CASE
                    WHEN EXTRACT(week from post.post_time) = 0
                    THEN EXTRACT(year from post.post_time) *100 + EXTRACT(week from post.post_time) + 1
                    ELSE EXTRACT(year from post.post_time) *100 + EXTRACT(week from post.post_time)
                END
            ) = followers.week_num
    LEFT JOIN edge_followers AS asc_followers
        ON post.platform_user_id = asc_followers.platform_user_id
            AND post.platform = asc_followers.platform
            AND kol_url.kol_id = asc_followers.kol_id
            AND asc_followers.row_num_asc = 1
    LEFT JOIN renata_rawdata_all.ml_text_sponsor AS sponsor
        ON sponsor.post_id = post.platform_post_id
    WHERE post.post_time BETWEEN TIMESTAMP(DATETIME_SUB(current_dt, INTERVAL 180 DAY)) AND TIMESTAMP(current_dt)
)
;
