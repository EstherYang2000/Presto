/*
- Target: 計算 KOL 粉絲品質，產出欄位 credibility 粉絲可信度
- Source: renata_rawdata_all.latest_instagram_follower,
          renata_rawdata_all.instagram_follower_profile
- Description:
  1. 取得各個 KOL(platform_user_id) 的粉絲資訊
  2. 計算各粉絲(follower_id)是否為假粉, 判定標準：follower_id 的粉絲數、追蹤數、貼文數
  3. 計算每個 KOL 的假粉比率（被定義為假粉的粉絲/所有有被爬的粉絲數）
*/

DECLARE follow_count_bound INT64;
DECLARE follower_count_bound INT64;
DECLARE post_count_bound INT64;

SET follow_count_bound = {follow_count_bound};
SET follower_count_bound = {follower_count_bound};
SET post_count_bound = {post_count_bound};


DROP TABLE IF EXISTS `renata_feature.platform_account_follower_quality_ai_latest`;
CREATE TABLE IF NOT EXISTS `renata_feature.platform_account_follower_quality_ai_latest` AS(

-- 取得各個 platform_user_id 及其粉絲資訊
WITH
    follower_table AS(
        SELECT
            follower.platform,
            follower.platform_user_id,
            follower.follower_id,
            follower_info.follow_count,
            follower_info.follower_count,
            follower_info.post_count
        FROM `renata_rawdata_all.latest_instagram_follower` AS follower
        LEFT JOIN `renata_rawdata_all.instagram_follower_profile` AS follower_info
            ON follower.follower_id = follower_info.platform_user_id

    ),
    
-- 計算每個 follower_id 是否為假粉
    follower_detection AS(
        SELECT 
            platform,
            platform_user_id,
            follower_id,
            CASE
                WHEN follow_count > follow_count_bound 
                    AND follower_count < follower_count_bound
                    AND post_count < post_count_bound 
                THEN TRUE
                ELSE FALSE
            END AS is_fake_fan
        FROM follower_table

    )

-- 計算每個 KOL 的假粉比率，而 1 - 假粉比率即為 credibility
SELECT 
    platform,
    platform_user_id,
    1 - SAFE_DIVIDE(COUNT(DISTINCT(IF(is_fake_fan IS TRUE, follower_id, NULL))),
                    COUNT(DISTINCT follower_id)) 
    AS credibility,
    CURRENT_TIMESTAMP() AS created_at,
    CURRENT_TIMESTAMP() AS etl_at
FROM follower_detection
GROUP BY platform, platform_user_id
    
);


-- 建立粉絲品質的 hist table
CREATE TABLE IF NOT EXISTS `renata_feature.platform_account_follower_quality_ai_hist` (
    platform STRING,
    platform_user_id STRING,
    credibility FLOAT64,
    created_at TIMESTAMP,
    etl_at TIMESTAMP
)

PARTITION BY DATE_TRUNC(created_at, MONTH) ;

INSERT INTO `renata_feature.platform_account_follower_quality_ai_hist`
SELECT 
    * 
FROM `renata_feature.platform_account_follower_quality_ai_latest`;