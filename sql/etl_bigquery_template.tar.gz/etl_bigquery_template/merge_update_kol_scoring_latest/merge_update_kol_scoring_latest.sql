DECLARE current_dt DATETIME DEFAULT(CURRENT_DATETIME());
DROP TABLE IF EXISTS renata_feature.kol_scoring_latest;
CREATE TABLE renata_feature.kol_scoring_latest AS
(
    WITH
        cte AS (
            SELECT
                *,
                MAX(etl_at) OVER (PARTITION BY kol_id, platform, platform_user_id) AS max_etl_at
            FROM renata_feature.kol_scoring_hist
        ),
        latest AS (
            SELECT
            current_dt AS etl_at,
            kol_id,
            country,
            platform,
            platform_user_id,
            score,
            score_type,
            etl_at AS calculated_base_date,
            0 AS score_growth,
            'current' AS time_type
            FROM cte
            WHERE etl_at = max_etl_at
        ),
        m1 AS (
            SELECT
                current_dt AS etl_at,
                m1.kol_id,
                m1.country,
                m1.platform,
                m1.platform_user_id,
                m1.score,
                m1.score_type,
                m1.etl_at AS calculated_base_date,
                IFNULL(SAFE_DIVIDE(latest.score - m1.score, m1.score),0) AS score_growth,
                'm1' AS time_type
            FROM (
            SELECT
                *,
                FIRST_VALUE(etl_at)
                OVER (PARTITION BY kol_id, platform, platform_user_id ORDER BY etl_at DESC
                ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS time_1m
            FROM cte
            WHERE etl_at BETWEEN DATE_SUB(DATE_TRUNC(max_etl_at, MONTH), INTERVAL 30 DAY) AND
                            DATE_TRUNC(max_etl_at, MONTH)
            ) m1
            LEFT JOIN latest
                ON m1.kol_id = latest.kol_id
                AND m1.platform = latest.platform
                AND m1.platform_user_id = latest.platform_user_id
            WHERE m1.etl_at = time_1m
        ),
        m3 AS (
            SELECT
                current_dt AS etl_at,
                m3.kol_id,
                m3.country,
                m3.platform,
                m3.platform_user_id,
                m3.score,
                m3.score_type,
                m3.etl_at AS calculated_base_date,
                IFNULL(SAFE_DIVIDE(latest.score - m3.score, m3.score),0) AS score_growth,
                'm3' AS time_type
            FROM (
            SELECT
                *,
                FIRST_VALUE(etl_at)
                OVER (PARTITION BY kol_id, platform, platform_user_id ORDER BY etl_at DESC
                ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS time_3m
            FROM cte
            WHERE etl_at BETWEEN DATE_SUB(DATE_TRUNC(max_etl_at, MONTH), INTERVAL 90 DAY) AND
                            DATE_SUB(DATE_TRUNC(max_etl_at, MONTH), INTERVAL 60 DAY)
            ) m3
            LEFT JOIN latest
                ON m3.kol_id = latest.kol_id
                AND m3.platform = latest.platform
                AND m3.platform_user_id = latest.platform_user_id
            WHERE m3.etl_at = time_3m
        ),
        m6 AS (
            SELECT
                current_dt AS etl_at,
                m6.kol_id,
                m6.country,
                m6.platform,
                m6.platform_user_id,
                m6.score,
                m6.score_type,
                m6.etl_at AS calculated_base_date,
                IFNULL(SAFE_DIVIDE(latest.score - m6.score, m6.score),0) AS score_growth,
                'm6' AS time_type
            FROM (
            SELECT
                *,
                FIRST_VALUE(etl_at)
                OVER (PARTITION BY kol_id, platform, platform_user_id ORDER BY etl_at DESC
                ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS time_6m
            FROM cte
            WHERE etl_at BETWEEN DATE_SUB(DATE_TRUNC(max_etl_at, MONTH), INTERVAL 180 DAY) AND
                            DATE_SUB(DATE_TRUNC(max_etl_at, MONTH), INTERVAL 150 DAY)
            ) m6
            LEFT JOIN latest
                ON m6.kol_id = latest.kol_id
                AND m6.platform = latest.platform
                AND m6.platform_user_id = latest.platform_user_id
            WHERE m6.etl_at = time_6m
        )
        SELECT
        *
        FROM latest

        UNION ALL

        SELECT
            *
        FROM m1

        UNION ALL

        SELECT
            *
        FROM m3

        UNION ALL

        SELECT
            *
        FROM m6
)
;