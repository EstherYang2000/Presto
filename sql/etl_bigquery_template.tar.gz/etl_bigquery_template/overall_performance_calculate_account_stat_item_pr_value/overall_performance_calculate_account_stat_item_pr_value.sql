/*
- Target: 整理各 KOL 各項指標統計量、計算其 PR 值
- Source: renata_etl_temp.group_indicators_stat
- Description:
  1. 整理各 KOL 各項指標統計量、計算其 PR 值
  2. 將結果存在 renata_feature.personal_pr_value_performance_latest
  3. 存一份資料進 renata_feature.personal_pr_value_performance_hist
*/
DROP TABLE IF EXISTS renata_feature.personal_pr_value_performance_latest;
CREATE TABLE renata_feature.personal_pr_value_performance_latest AS(
    SELECT 
        indicators_stat.*,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY follower_growth_1m ASC))*100/total_kol_count) AS follower_growth_1m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY follower_growth_3m ASC))*100/total_kol_count) AS follower_growth_3m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY follower_growth_6m ASC))*100/total_kol_count) AS follower_growth_6m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY reaction_rate_1m ASC))*100/total_kol_count) AS reaction_rate_1m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY reaction_rate_3m ASC))*100/total_kol_count) AS reaction_rate_3m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY reaction_rate_6m ASC))*100/total_kol_count) AS reaction_rate_6m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY short_reaction_rate_1m ASC))*100/total_kol_count) AS short_reaction_rate_1m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY short_reaction_rate_3m ASC))*100/total_kol_count) AS short_reaction_rate_3m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY short_reaction_rate_6m ASC))*100/total_kol_count) AS short_reaction_rate_6m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY video_view_rate_1m ASC))*100/total_kol_count) AS video_view_rate_1m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY video_view_rate_3m ASC))*100/total_kol_count) AS video_view_rate_3m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY video_view_rate_6m ASC))*100/total_kol_count) AS video_view_rate_6m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY short_view_rate_1m ASC))*100/total_kol_count) AS short_view_rate_1m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY short_view_rate_3m ASC))*100/total_kol_count) AS short_view_rate_3m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY short_view_rate_6m ASC))*100/total_kol_count) AS short_view_rate_6m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY short_play_rate_1m ASC))*100/total_kol_count) AS short_play_rate_1m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY short_play_rate_3m ASC))*100/total_kol_count) AS short_play_rate_3m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY short_play_rate_6m ASC))*100/total_kol_count) AS short_play_rate_6m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY post_count_sum_1m ASC))*100/total_kol_count) AS post_count_sum_1m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY post_count_sum_3m ASC))*100/total_kol_count) AS post_count_sum_3m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY post_count_sum_6m ASC))*100/total_kol_count) AS post_count_sum_6m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY sponsor_post_ratio_1m ASC))*100/total_kol_count) AS sponsor_post_ratio_1m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY sponsor_post_ratio_3m ASC))*100/total_kol_count) AS sponsor_post_ratio_3m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY sponsor_post_ratio_6m ASC))*100/total_kol_count) AS sponsor_post_ratio_6m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY like_comment_ratio_1m ASC))*100/total_kol_count) AS like_comment_ratio_1m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY like_comment_ratio_3m ASC))*100/total_kol_count) AS like_comment_ratio_3m_pr_value,
        CEIL((RANK() OVER (PARTITION BY platform, follower_group ORDER BY like_comment_ratio_6m ASC))*100/total_kol_count) AS like_comment_ratio_6m_pr_value,
        DATE(DATE_TRUNC(CURRENT_TIMESTAMP(), MONTH)) AS calculate_base_date,
        CURRENT_TIMESTAMP() AS etl_at
    FROM renata_etl_temp.group_indicators_stat AS indicators_stat
);

CREATE TABLE IF NOT EXISTS renata_feature.personal_pr_value_performance_hist
(
    kol_id INT64,
    platform STRING,
    platform_user_id STRING,
    follower_group STRING,
    follower_group_enum STRING,
    follower_growth_1m FLOAT64,
    follower_growth_3m FLOAT64,
    follower_growth_6m FLOAT64,
    reaction_rate_1m FLOAT64,
    reaction_rate_3m FLOAT64,
    reaction_rate_6m FLOAT64,
    short_reaction_rate_1m FLOAT64,
    short_reaction_rate_3m FLOAT64,
    short_reaction_rate_6m FLOAT64,
    video_view_rate_1m FLOAT64,
    video_view_rate_3m FLOAT64,
    video_view_rate_6m FLOAT64,
    short_view_rate_1m FLOAT64,
    short_view_rate_3m FLOAT64,
    short_view_rate_6m FLOAT64,
    short_play_rate_1m FLOAT64,
    short_play_rate_3m FLOAT64,
    short_play_rate_6m FLOAT64,
    post_count_sum_1m INT64,
    post_count_sum_3m INT64,
    post_count_sum_6m INT64,
    sponsor_post_ratio_1m FLOAT64,
    sponsor_post_ratio_3m FLOAT64,
    sponsor_post_ratio_6m FLOAT64,
    like_comment_ratio_1m FLOAT64,
    like_comment_ratio_3m FLOAT64,
    like_comment_ratio_6m FLOAT64,
    total_kol_count INT64,
    follower_growth_1m_pr_value FLOAT64,
    follower_growth_3m_pr_value FLOAT64,
    follower_growth_6m_pr_value FLOAT64,
    reaction_rate_1m_pr_value FLOAT64,
    reaction_rate_3m_pr_value FLOAT64,
    reaction_rate_6m_pr_value FLOAT64,
    short_reaction_rate_1m_pr_value FLOAT64,
    short_reaction_rate_3m_pr_value FLOAT64,
    short_reaction_rate_6m_pr_value FLOAT64,
    video_view_rate_1m_pr_value FLOAT64,
    video_view_rate_3m_pr_value FLOAT64,
    video_view_rate_6m_pr_value FLOAT64,
    short_view_rate_1m_pr_value FLOAT64,
    short_view_rate_3m_pr_value FLOAT64,
    short_view_rate_6m_pr_value FLOAT64,
    short_play_rate_1m_pr_value FLOAT64,
    short_play_rate_3m_pr_value FLOAT64,
    short_play_rate_6m_pr_value FLOAT64,
    post_count_sum_1m_pr_value FLOAT64,
    post_count_sum_3m_pr_value FLOAT64,
    post_count_sum_6m_pr_value FLOAT64,
    sponsor_post_ratio_1m_pr_value FLOAT64,
    sponsor_post_ratio_3m_pr_value FLOAT64,
    sponsor_post_ratio_6m_pr_value FLOAT64,
    like_comment_ratio_1m_pr_value FLOAT64,
    like_comment_ratio_3m_pr_value FLOAT64,
    like_comment_ratio_6m_pr_value FLOAT64,
    calculate_base_date DATE,
    etl_at TIMESTAMP
)
PARTITION BY DATE_TRUNC(calculate_base_date, MONTH) ;

INSERT INTO `renata_feature.personal_pr_value_performance_hist`
SELECT 
    * 
FROM `renata_feature.personal_pr_value_performance_latest`;