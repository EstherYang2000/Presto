/*
[Overview] 
取出製作愛卡拉輿情分析儀表板所需資料: 愛卡拉官方帳號輿情監控
*/

-- 篩選時間: 以執行排成當下為結束時間，往前推 4 個月為起始時間
DECLARE end_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP();
DECLARE start_date TIMESTAMP;
DECLARE week_num_start_date INT64;
DECLARE week_num_end_date INT64;

SET start_date = (
    SELECT TIMESTAMP(DATETIME(DATE_SUB(DATE(end_date), INTERVAL 4 MONTH)))
);

SET week_num_start_date = (
    SELECT
        CASE
            WHEN MOD(EXTRACT(year FROM start_date) * 100 + EXTRACT(week FROM start_date), 100) = 0
            THEN EXTRACT(year FROM start_date) * 100 + EXTRACT(week FROM start_date) + 1
            ELSE EXTRACT(year FROM start_date) * 100 + EXTRACT(week FROM start_date)
        END
);

SET week_num_end_date = (
    SELECT
        CASE
            WHEN MOD(EXTRACT(year FROM end_date) * 100 + EXTRACT(week FROM end_date), 100) = 0
            THEN EXTRACT(year FROM end_date) * 100 + EXTRACT(week FROM end_date) + 1
            ELSE EXTRACT(year FROM end_date) * 100 + EXTRACT(week FROM end_date)
        END
);

-- 建立可篩選條件的 KOL table, 條件:
-- 1. status 為 activated 或 activate
-- 2. kol type 不是 seller 或 industry_economics
-- 3. url 狀態為 activated
-- 4. 國家為台灣或日本

DROP TABLE IF EXISTS `renata_etl_temp.ikala_account_public_opinion_kol` ;
CREATE TABLE IF NOT EXISTS `renata_etl_temp.ikala_account_public_opinion_kol` 
AS (
    SELECT 
        t1.id AS kol_id,
        t1.name,
        t1.created_by,
        t3.name AS kol_type,
        t1.status AS kol_status,
        t4.status AS url_status,
        t4.platform_user_id,
        t4.platform,
        t4.url AS platform_url,
        t4.kol_platform_name,
        t2.name_tw AS country,
        CONCAT('https://app.kolradar.com/kol/',  t1.radar_uuid) AS radar_url,
    FROM `renata_rawdata_all.kol` AS t1
    LEFT JOIN `renata_rawdata_all.country` AS t2
        ON t1.country_id = t2.id
    LEFT JOIN `renata_rawdata_all.kol_type` AS t3
        ON t1.type_id = t3.id
    INNER JOIN `renata_rawdata_all.kol_url` AS t4
        ON t1.id = t4.kol_id
    WHERE (t1.status = 'activated' OR t1.status = 'activate')
        AND t3.name != 'seller'
        AND t3.name != 'industry_economics'
        AND t4.status = 'activated'
        AND t2.name_tw IN ('台灣','日本')
   );

-- 取得愛卡拉官方帳號的資訊
DROP TABLE IF EXISTS `renata_ds_report_dashboard.ikala_public_opinion_official_account_kol`;
CREATE TABLE IF NOT EXISTS `renata_ds_report_dashboard.ikala_public_opinion_official_account_kol` AS(    
    SELECT DISTINCT
        kol_url.kol_id,
        kol_url.platform_user_id,
        kol_url.url,
        kol_url.platform,
        kol_url.kol_platform_name,
        kol.name,
        CASE 
            WHEN kol_url.platform = 'ig'
            THEN profile_ig.name
            WHEN kol_url.platform = 'fb'
            THEN profile_fb.name
            WHEN kol_url.platform = 'yt'
            THEN profile_yt.name
            ELSE NULL
        END AS platform_name,
        CONCAT('https://app.kolradar.com/kol/',  kol.radar_uuid) AS radar_url,
        country.name_tw AS country
        FROM `renata_rawdata_all.kol_url` AS kol_url
        INNER JOIN `renata_rawdata_all.kol` AS kol
            ON kol_url.kol_id = kol.id
        LEFT JOIN `renata_rawdata_all.country` AS country
            ON kol.country_id = country.id
        LEFT JOIN `renata_rawdata_all.latest_instagram_profile` AS profile_ig
            ON kol_url.platform_user_id = profile_ig.platform_user_id
        LEFT JOIN `renata_rawdata_all.latest_facebook_profile` AS profile_fb
            ON kol_url.platform_user_id = profile_fb.platform_user_id
        LEFT JOIN `renata_rawdata_all.latest_youtube_profile` AS profile_yt
            ON kol_url.platform_user_id = profile_yt.platform_user_id
        WHERE url IN(
            'https://www.instagram.com/kolradar_tw/',
            'https://www.facebook.com/kolradar.global/',
            'https://www.facebook.com/iKala.Cloud',
            'https://www.facebook.com/iKala.tv/',
            'https://www.youtube.com/channel/UC0SRB1NANI9mL5FEbs6vtjw'
            )
        ORDER BY kol_url.kol_id, kol_url.platform_user_id
    
);

-- 取得愛卡拉官方帳號的粉絲數
-- 取得該官方帳號在那段時間內的粉絲數、近三個月粉絲數成長率、近六個月粉絲數成長率
DROP TABLE IF EXISTS `renata_ds_report_dashboard.ikala_public_opinion_official_account_follower`;
CREATE TABLE IF NOT EXISTS `renata_ds_report_dashboard.ikala_public_opinion_official_account_follower` AS(
WITH
    stat_info AS (
        SELECT
            kol_id,
            platform,
            platform_user_id,
            current_follower,
            m3_follower,
            m3_follow_growth,
            m3_follow_growth_rate,
            m6_follower,
            m6_follow_growth,
            m6_follow_growth_rate,
            updated_at
        FROM `renata_rawdata_all.kol_fb_stat`
        UNION ALL
        SELECT
            kol_id,
            platform,
            platform_user_id,
            current_follower,
            m3_follower,
            m3_follow_growth,
            m3_follow_growth_rate,
            m6_follower,
            m6_follow_growth,
            m6_follow_growth_rate,
            updated_at
        FROM `renata_rawdata_all.kol_ig_stat`
        UNION ALL
        SELECT
            kol_id,
            platform,
            platform_user_id,
            current_follower,
            m3_follower,
            m3_follow_growth,
            m3_follow_growth_rate,
            m6_follower,
            m6_follow_growth,
            m6_follow_growth_rate,
            updated_at
        FROM `renata_rawdata_all.kol_yt_stat`
    )
SELECT 
    kol_info.*,
    stat_info.* EXCEPT(kol_id, platform_user_id, platform)
FROM stat_info
INNER JOIN `renata_ds_report_dashboard.ikala_public_opinion_official_account_kol` AS kol_info
 ON stat_info.kol_id = kol_info.kol_id
AND stat_info.platform_user_id = kol_info.platform_user_id
AND stat_info.platform = kol_info.platform
ORDER BY updated_at DESC

);


-- 取得符合範圍內的所有 kol 在三平台所發得貼文
DROP TABLE IF EXISTS `renata_ds_report_dashboard.ikala_public_opinion_post`;
CREATE TABLE IF NOT EXISTS `renata_ds_report_dashboard.ikala_public_opinion_post` AS(   
WITH 
    -- 取得在那期間內的最一開始粉絲數和最後粉絲數
    edge_followers AS (
        SELECT DISTINCT 
            kol_id,
            platform_user_id,
            platform,
            follower_count_processed,
            week_num,
            ROW_NUMBER() OVER (PARTITION BY kol_id, platform, platform_user_id ORDER BY week_num DESC) AS row_num_desc,
            ROW_NUMBER() OVER (PARTITION BY kol_id, platform, platform_user_id ORDER BY week_num ASC) AS row_num_asc
        FROM `renata_rawdata_all.kol_followers`
        WHERE follower_count_processed > 0
            AND platform_user_id <> 'undefined'
            AND week_num BETWEEN week_num_start_date AND week_num_end_date

    ),

    ig_post AS(
        SELECT
            ig_post.platform_post_id,
            ig_post.platform,
            DATETIME(ig_post.post_time, 'Asia/Taipei') AS post_time,
            EXTRACT(YEAR FROM DATETIME(ig_post.post_time, 'Asia/Taipei')) * 100 + EXTRACT(WEEK FROM DATETIME(ig_post.post_time, 'Asia/Taipei')) AS post_week,
            kol_info.name,
            kol_info.country,
            kol_info.kol_platform_name,
            kol_info.kol_id,
            ig_post.platform_user_id,
            ig_post.content,
            kol_info.radar_url,
            ig_post.url,
            desc_followers.follower_count_processed AS follower_count_latest,
            COALESCE(
                followers.follower_count_processed,
                FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY ig_post.platform_user_id
                                                                                                ORDER BY ig_post.post_time
                                                                                                ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
                                                                                            ),
                FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY ig_post.platform_user_id
                                                                                                ORDER BY ig_post.post_time
                                                                                                ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                                                                                            ),
                asc_followers.follower_count_processed
            ) AS follower_count_then,
            CASE  
                WHEN ig_post.platform = 'fb' 
                THEN CAST((view_count * 0.1 + like_count * 0.2 + comment_count * 0.3 + share_count * 0.4) AS NUMERIC)
                WHEN ig_post.platform = 'ig' 
                THEN CAST((view_count * 0.2 + like_count * 0.3 + comment_count * 0.5) AS NUMERIC)
                WHEN ig_post.platform = 'yt' 
                THEN CAST((view_count * 0.1 + like_count * 0.3 + comment_count * 0.6) AS NUMERIC)
                ELSE NULL 
            END AS voice,
            ig_post.like_count + ig_post.comment_count + ig_post.share_count AS reaction_count,
            ig_post.comment_count,
            ig_post.share_count,
            ig_post.view_count,
            ig_post.like_count,
            ig_post.play_count,
            ig_post.is_video,  
            hashtag.hashtag_content AS hashtags, 
            CURRENT_DATE('Asia/Taipei') AS table_updated_date 
        FROM `renata_rawdata_all.latest_instagram_post` AS ig_post
        INNER JOIN `renata_etl_temp.ikala_account_public_opinion_kol` AS kol_info
            ON ig_post.platform_user_id = kol_info.platform_user_id 
                AND ig_post.platform = kol_info.platform 
                AND kol_info.platform = 'ig'
        LEFT JOIN edge_followers AS asc_followers
            ON ig_post.platform_user_id = asc_followers.platform_user_id
                AND kol_info.platform = asc_followers.platform
                AND kol_info.kol_id = asc_followers.kol_id
                AND asc_followers.row_num_asc = 1
                AND asc_followers.platform = 'ig'
        LEFT JOIN edge_followers AS desc_followers
            ON ig_post.platform_user_id = desc_followers.platform_user_id
                AND kol_info.platform = desc_followers.platform
                AND kol_info.kol_id = desc_followers.kol_id
                AND desc_followers.row_num_desc = 1
                AND desc_followers.platform = 'ig'        
        LEFT JOIN edge_followers AS followers 
            ON ig_post.platform_user_id = followers.platform_user_id
                AND kol_info.platform = followers.platform
                AND kol_info.kol_id = followers.kol_id
                AND EXTRACT(YEAR from ig_post.post_time) * 100 + EXTRACT(WEEK from ig_post.post_time) = followers.week_num
                AND followers.platform = 'ig'
        LEFT JOIN `renata_rawdata_all.latest_instagram_post_hashtag` AS hashtag
            ON ig_post.platform_post_id = hashtag.platform_post_id
                AND ig_post.platform_user_id = hashtag.platform_user_id
        WHERE ig_post.post_time BETWEEN start_date AND end_date

    ),
    fb_post AS(
        SELECT
            fb_post.platform_post_id,
            fb_post.platform,
            DATETIME(fb_post.post_time, 'Asia/Taipei') AS post_time,
            EXTRACT(YEAR FROM DATETIME(fb_post.post_time, 'Asia/Taipei')) * 100 + EXTRACT(WEEK FROM DATETIME(fb_post.post_time, 'Asia/Taipei')) AS post_week,
            kol_info.name,
            kol_info.country,
            kol_info.kol_platform_name,
            kol_info.kol_id,
            fb_post.platform_user_id,
            fb_post.content,
            kol_info.radar_url,
            fb_post.url,
            desc_followers.follower_count_processed AS follower_count_latest,
            COALESCE(
                followers.follower_count_processed,
                FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY fb_post.platform_user_id
                                                                                              ORDER BY fb_post.post_time
                                                                                                ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
                                                                                            ),
                FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY fb_post.platform_user_id
                                                                                              ORDER BY fb_post.post_time
                                                                                              ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                                                                                            ),
                asc_followers.follower_count_processed
            ) AS follower_count_then,
            CASE  
                WHEN fb_post.platform = 'fb' 
                THEN CAST((view_count * 0.1 + like_count * 0.2 + comment_count * 0.3 + share_count * 0.4) AS NUMERIC)
                WHEN fb_post.platform = 'ig' 
                THEN CAST((view_count * 0.2 + like_count * 0.3 + comment_count * 0.5) AS NUMERIC)
                WHEN fb_post.platform = 'yt' 
                THEN CAST((view_count * 0.1 + like_count * 0.3 + comment_count * 0.6) AS NUMERIC)
                ELSE NULL 
            END AS voice,
            fb_post.like_count + fb_post.comment_count + fb_post.share_count AS reaction_count,
            fb_post.comment_count,
            fb_post.share_count,
            fb_post.view_count,
            fb_post.like_count,
            NULL AS play_count,
            fb_post.is_video,
            hashtag.hashtag_content AS hashtags,
            CURRENT_DATE('Asia/Taipei') AS table_updated_date
        FROM `renata_rawdata_all.latest_facebook_post` AS fb_post
        INNER JOIN `renata_etl_temp.ikala_account_public_opinion_kol` AS kol_info
            ON fb_post.platform_user_id = kol_info.platform_user_id 
                AND fb_post.platform = kol_info.platform 
                AND kol_info.platform = 'fb'
        LEFT JOIN edge_followers AS asc_followers
            ON fb_post.platform_user_id = asc_followers.platform_user_id
                AND kol_info.platform = asc_followers.platform
                AND kol_info.kol_id = asc_followers.kol_id
                AND asc_followers.row_num_asc = 1
                AND asc_followers.platform = 'fb'
        LEFT JOIN edge_followers AS desc_followers
            ON fb_post.platform_user_id = desc_followers.platform_user_id
                AND kol_info.platform = desc_followers.platform
                AND kol_info.kol_id = desc_followers.kol_id
                AND desc_followers.row_num_desc = 1
                AND desc_followers.platform = 'fb'        
        LEFT JOIN edge_followers AS followers 
            ON fb_post.platform_user_id = followers.platform_user_id
                AND kol_info.platform = followers.platform
                AND kol_info.kol_id = followers.kol_id
                AND EXTRACT(YEAR from fb_post.post_time) * 100 + EXTRACT(WEEK from fb_post.post_time) = followers.week_num
                AND followers.platform = 'fb'
        LEFT JOIN `renata_rawdata_all.latest_facebook_post_hashtag` AS hashtag
            ON fb_post.platform_post_id = hashtag.platform_post_id
                AND fb_post.platform_user_id = hashtag.platform_user_id
        WHERE fb_post.post_time BETWEEN start_date AND end_date

    ),

yt_post AS(
        SELECT
            yt_post.platform_post_id,
            yt_post.platform,
            DATETIME(yt_post.post_time, 'Asia/Taipei') AS post_time,
            EXTRACT(YEAR FROM DATETIME(yt_post.post_time, 'Asia/Taipei')) * 100 + EXTRACT(WEEK FROM DATETIME(yt_post.post_time, 'Asia/Taipei')) AS post_week,
            kol_info.name,
            kol_info.country,
            kol_info.kol_platform_name,
            kol_info.kol_id,
            yt_post.platform_user_id,
            yt_post.content,
            kol_info.radar_url,
            yt_post.url,
            desc_followers.follower_count_processed AS follower_count_latest,
            COALESCE(
                followers.follower_count_processed,
                FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY yt_post.platform_user_id
                                                                                              ORDER BY yt_post.post_time
                                                                                                ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
                                                                                            ),
                FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY yt_post.platform_user_id
                                                                                              ORDER BY yt_post.post_time
                                                                                              ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                                                                                            ),
                asc_followers.follower_count_processed
            ) AS follower_count_then,
            CASE  
                WHEN yt_post.platform = 'fb' 
                THEN CAST((view_count * 0.1 + like_count * 0.2 + comment_count * 0.3 + share_count * 0.4) AS NUMERIC)
                WHEN yt_post.platform = 'ig' 
                THEN CAST((view_count * 0.2 + like_count * 0.3 + comment_count * 0.5) AS NUMERIC)
                WHEN yt_post.platform = 'yt' 
                THEN CAST((view_count * 0.1 + like_count * 0.3 + comment_count * 0.6) AS NUMERIC)
                ELSE NULL 
            END AS voice,
            yt_post.like_count + yt_post.comment_count + yt_post.share_count AS reaction_count,
            yt_post.comment_count,
            yt_post.share_count,
            yt_post.view_count,
            yt_post.like_count,
            NULL AS play_count,
            yt_post.is_video,
            hashtag.hashtag_content AS hashtags,
            CURRENT_DATE('Asia/Taipei') AS table_updated_date
        FROM `renata_rawdata_all.latest_youtube_post` AS yt_post
        INNER JOIN  `renata_etl_temp.ikala_account_public_opinion_kol` AS kol_info
            ON yt_post.platform_user_id = kol_info.platform_user_id 
                AND yt_post.platform = kol_info.platform 
                AND kol_info.platform = 'yt'
        LEFT JOIN edge_followers AS asc_followers
            ON yt_post.platform_user_id = asc_followers.platform_user_id
                AND kol_info.platform = asc_followers.platform
                AND kol_info.kol_id = asc_followers.kol_id
                AND asc_followers.row_num_asc = 1
                AND asc_followers.platform = 'yt'
        LEFT JOIN edge_followers AS desc_followers
            ON yt_post.platform_user_id = desc_followers.platform_user_id
                AND kol_info.platform = desc_followers.platform
                AND kol_info.kol_id = desc_followers.kol_id
                AND desc_followers.row_num_desc = 1
                AND desc_followers.platform = 'yt'        
        LEFT JOIN edge_followers AS followers 
            ON yt_post.platform_user_id = followers.platform_user_id
                AND kol_info.platform = followers.platform
                AND kol_info.kol_id = followers.kol_id
                AND EXTRACT(YEAR from yt_post.post_time) * 100 + EXTRACT(WEEK from yt_post.post_time) = followers.week_num
                AND followers.platform = 'yt'
        LEFT JOIN `renata_rawdata_all.latest_youtube_post_hashtag` AS hashtag
            ON yt_post.platform_post_id = hashtag.platform_post_id
                AND yt_post.platform_user_id = hashtag.platform_user_id
        WHERE yt_post.post_time BETWEEN start_date AND end_date

    )

SELECT 
    *,
    CASE 
        WHEN follower_count_latest >= 0 AND follower_count_latest < 10000 
        THEN "A.<10K"
        WHEN follower_count_latest >= 10000 AND follower_count_latest < 30000 
        THEN "B.10K-30K"
        WHEN follower_count_latest >= 30000 AND follower_count_latest < 50000 
        THEN "C.30K-50K"
        WHEN follower_count_latest >= 50000 AND follower_count_latest < 100000 
        THEN "D.50K-100K"
        WHEN follower_count_latest >= 100000 AND follower_count_latest < 300000 
        THEN "E.100K-300K"
        WHEN follower_count_latest >= 300000 AND follower_count_latest < 500000 
        THEN "F.300K-500K"
        WHEN follower_count_latest >= 500000 AND  follower_count_latest < 1000000 
        THEN "G.500K-1M"
        WHEN follower_count_latest >= 1000000 THEN "H.1M+"
        ELSE NULL
    END AS follower_range

FROM (
    SELECT 
        *
    FROM ig_post
    UNION ALL 
    SELECT 
        *
    FROM fb_post
    UNION ALL 
    SELECT 
        *
    FROM yt_post
)
);

--從所有貼文中選出是官方帳號所發佈的貼文
DROP TABLE IF EXISTS `renata_ds_report_dashboard.ikala_public_opinion_official_account_post`;
CREATE TABLE IF NOT EXISTS `renata_ds_report_dashboard.ikala_public_opinion_official_account_post` AS(   
SELECT 
    post.*,
    kol.platform_name
FROM `renata_ds_report_dashboard.ikala_public_opinion_post` AS post
INNER JOIN `renata_ds_report_dashboard.ikala_public_opinion_official_account_kol` AS kol
    ON post.platform_user_id = kol.platform_user_id
    AND post.platform = kol.platform
    AND post.kol_id = kol.kol_id
);

/*
[Overview] 
取出製作愛卡拉輿情分析儀表板所需資料: 整體 hashtags 提及監控
*/

-- 選出所需欄位 並將 hashtag unnest
DROP TABLE IF EXISTS `renata_ds_report_dashboard.ikala_account_public_opinion_post_hashtag`;
CREATE TABLE IF NOT EXISTS `renata_ds_report_dashboard.ikala_account_public_opinion_post_hashtag`AS(
SELECT 
    post.platform_post_id,
    post.platform_user_id,
    post.platform,
    post.url,
    post.name,
    post.country,
    post.post_week,
    post.post_time,
    post.table_updated_date,
    post.voice,
    post.follower_count_latest,
    post.follower_range,
    REPLACE(hashtag_unnest,'"','')  AS hashtags,
FROM `renata_ds_report_dashboard.ikala_public_opinion_post` AS post,
    UNNEST(JSON_EXTRACT_ARRAY(hashtags)) AS hashtag_unnest
);

-- 計算 hashtag 週聲量、使用人數、熱度分數
DROP TABLE IF EXISTS `renata_etl_temp.ikala_account_public_opinion_post_hashtags_sum`;
CREATE TABLE IF NOT EXISTS `renata_etl_temp.ikala_account_public_opinion_post_hashtags_sum` 
AS (
    SELECT
        *,
        ROUND(PERCENT_RANK() OVER(PARTITION BY post_week, platform, country 
                                  ORDER BY nonlinear_index ) * 100 ,2 ) AS nonlinear_PR,
    FROM (
        SELECT 
            *,
            ROUND(LOG(IFNULL(weekly_voice + 1  , 1), 15) *
                  LOG(IFNULL(weekly_kol_cnt + 1, 1), 2), 3) 
            AS nonlinear_index
        FROM (
            SELECT 
                post.hashtags,
                post.post_week,
                post.platform,
                post.country,
                ROUND(SUM(post.voice) ,3) AS weekly_voice,
                COUNT(DISTINCT post.platform_user_id) AS weekly_kol_cnt
            FROM `renata_ds_report_dashboard.ikala_account_public_opinion_post_hashtag` post 
            GROUP BY post.hashtags, post.post_week, post.platform, post.country
            )
        )
);

--為了後續將 hashtag 沒有數據的週數補零, 先建立 cross join table
DROP TABLE IF EXISTS `renata_etl_temp.ikala_account_public_opinion_cross_join` ;
CREATE TABLE IF NOT EXISTS `renata_etl_temp.ikala_account_public_opinion_cross_join` 
AS (
    WITH 
        post_week_table AS (
            SELECT DISTINCT 
                post_week,
                country
            FROM `renata_etl_temp.ikala_account_public_opinion_post_hashtags_sum` 
        ),
        autotag_hashtag AS (
            SELECT DISTINCT 
                hashtags
            FROM `renata_etl_temp.ikala_account_public_opinion_post_hashtags_sum` 
        )       

    SELECT 
        post_week,
        country,
        hashtags
    FROM post_week_table
    CROSS JOIN autotag_hashtag
);

-- 將 hashtag 沒有數據的週數補零，並拉出分平台、儀表板每週所需看到的項目包括前一週聲量等
DROP TABLE IF EXISTS `renata_ds_report_dashboard.ikala_account_public_opinion_hotness_table`;
CREATE TABLE IF NOT EXISTS `renata_ds_report_dashboard.ikala_account_public_opinion_hotness_table` 
AS (
    WITH 
        hotness_table AS(
            SELECT 
                cross_join.hashtags,
                cross_join.country,
                cross_join.post_week,
        
                IFNULL(instagram_week_hashtags.weekly_voice, 0) AS weekly_voice_ig,
                IFNULL(instagram_week_hashtags.weekly_kol_cnt, 0) AS weekly_kol_cnt_ig,
                IFNULL(instagram_week_hashtags.nonlinear_index, 0) AS nonlinear_index_ig,
                
                IFNULL(facebook_week_hashtags.weekly_voice, 0) AS weekly_voice_fb,
                IFNULL(facebook_week_hashtags.weekly_kol_cnt, 0) AS weekly_kol_cnt_fb,
                IFNULL(facebook_week_hashtags.nonlinear_index, 0) AS nonlinear_index_fb,
                

                IFNULL(youtube_week_hashtags.weekly_voice, 0) AS weekly_voice_yt,
                IFNULL(youtube_week_hashtags.weekly_kol_cnt, 0) AS weekly_kol_cnt_yt,
                IFNULL(youtube_week_hashtags.nonlinear_index, 0) AS nonlinear_index_yt,
                

            FROM `renata_etl_temp.ikala_account_public_opinion_cross_join` AS cross_join
            LEFT JOIN `renata_etl_temp.ikala_account_public_opinion_post_hashtags_sum` AS instagram_week_hashtags
                ON cross_join.hashtags = instagram_week_hashtags.hashtags 
                AND cross_join.country = instagram_week_hashtags.country
                AND cross_join.post_week = instagram_week_hashtags.post_week 
                AND instagram_week_hashtags.platform = 'ig'
             LEFT JOIN `renata_etl_temp.ikala_account_public_opinion_post_hashtags_sum` AS facebook_week_hashtags
                ON cross_join.hashtags = facebook_week_hashtags.hashtags 
                AND cross_join.country = facebook_week_hashtags.country
                AND cross_join.post_week = facebook_week_hashtags.post_week 
                AND facebook_week_hashtags.platform = 'fb' 
             LEFT JOIN `renata_etl_temp.ikala_account_public_opinion_post_hashtags_sum` AS youtube_week_hashtags
                ON cross_join.hashtags = youtube_week_hashtags.hashtags 
                AND cross_join.country = youtube_week_hashtags.country
                AND cross_join.post_week = youtube_week_hashtags.post_week 
                AND youtube_week_hashtags.platform = 'yt' 
          

        )
--計算熱度儀表板所需欄位
            SELECT  
                hashtags,
                country,
                post_week,
                weekly_voice_ig AS weekly_voice_ig_t1,
                weekly_kol_cnt_ig AS weekly_kol_cnt_ig_t1,
                nonlinear_index_ig AS nonlinear_index_ig_t1,

                -- IG hashtag 前一週聲量、使用人數、熱度分數計算
                LAG(weekly_voice_ig) OVER(PARTITION BY hashtags, country ORDER BY post_week) AS weekly_voice_ig_t0,
                LAG(weekly_kol_cnt_ig) OVER(PARTITION  BY hashtags, country ORDER BY post_week) AS weekly_kol_cnt_ig_t0, 
                LAG(nonlinear_index_ig) OVER(PARTITION  BY hashtags, country ORDER BY post_week) AS nonlinear_index_ig_t0,

                weekly_voice_fb AS weekly_voice_fb_t1,
                weekly_kol_cnt_fb AS weekly_kol_cnt_fb_t1,
                nonlinear_index_fb AS nonlinear_index_fb_t1,

                -- FB hashtag 前一週聲量、使用人數、熱度分數計算
                LAG(weekly_voice_fb) OVER(PARTITION BY hashtags, country ORDER BY post_week) AS weekly_voice_fb_t0,
                LAG(weekly_kol_cnt_fb) OVER(PARTITION  BY hashtags, country ORDER BY post_week) AS weekly_kol_cnt_fb_t0, 
                LAG(nonlinear_index_fb) OVER(PARTITION  BY hashtags, country ORDER BY post_week) AS nonlinear_index_fb_t0,


                weekly_voice_yt AS weekly_voice_yt_t1,
                weekly_kol_cnt_yt AS weekly_kol_cnt_yt_t1,
                nonlinear_index_yt AS nonlinear_index_yt_t1,

                -- YT hashtag 前一週聲量、使用人數、熱度分數計算
                LAG(weekly_voice_yt) OVER(PARTITION BY hashtags, country ORDER BY post_week) AS weekly_voice_yt_t0,
                LAG(weekly_kol_cnt_yt) OVER(PARTITION  BY hashtags, country ORDER BY post_week) AS weekly_kol_cnt_yt_t0, 
                LAG(nonlinear_index_yt) OVER(PARTITION  BY hashtags, country ORDER BY post_week) AS nonlinear_index_yt_t0,           
                CURRENT_DATE('Asia/Taipei') AS table_updated_date

            FROM hotness_table
            ORDER BY post_week DESC

    );

/*
由於折線圖會受到控制器設置 post_week 影響，若選擇單週的話折線圖便只能呈現單點。
因此多拉一個 table 將週次名稱改變，進而可看出基準週的數據資料，與整體週次的趨勢呈現。
*/
DROP TABLE IF EXISTS `renata_ds_report_dashboard.ikala_account_public_opinion_week_num`;
CREATE TABLE IF NOT EXISTS `renata_ds_report_dashboard.ikala_account_public_opinion_week_num` 
AS (

    SELECT  
        * except(post_week),
        post_week AS week_num
    FROM  `renata_ds_report_dashboard.ikala_account_public_opinion_hotness_table`

);

/*
[Overview] 
取出製作愛卡拉輿情分析儀表板所需資料: 整體關鍵字提及監控
*/


DROP TABLE IF EXISTS `renata_ds_report_dashboard.ikala_account_public_opinion_keyword`;
CREATE TABLE IF NOT EXISTS `renata_ds_report_dashboard.ikala_account_public_opinion_keyword` 
AS (

        SELECT 
            platform_post_id,
            platform_user_id,
            content,
            platform,
            url,
            name,
            country,
            post_week,
            post_time,
            table_updated_date,
            voice,
            follower_count_latest,
            follower_range
        FROM `renata_ds_report_dashboard.ikala_public_opinion_post` AS post
);