/*
- Target: 整理各 KOL 不同時間點的 follower 數量
- Source: renata_rawdata_all.kol_followers
- Description:
  1. 整理各 KOL 不同時間點的 follower 數量
  2. 將結果存在 renata_etl_temp.group_indicators_follower_info
*/
DECLARE current_dt DATETIME DEFAULT(DATE_TRUNC(CURRENT_DATETIME(), month));
DECLARE week_num_current INT64;
DECLARE week_num_1m INT64;
DECLARE week_num_2m INT64;
DECLARE week_num_3m INT64;
DECLARE week_num_4m INT64;
DECLARE week_num_5m INT64;
DECLARE week_num_6m INT64;


-- 由於 big query 的資料是一週更新一次，因此在 week_num_current 設定會有以下情境：
-- 若 current_datetime = 2023-05-31，其對應的 week_num 應為 202322，而 pg 上的 kol_followers 一定有 week_num = 202322 的資料，
-- 因為 pg 是每天執行 kol_followers ETL，所以不會有任何一個 week_num 會遺漏；但 big query 上的 kol_followers 是每週定期從 pg 上傳而來，
-- 因此可能出現需要的 202322 的資料但最多只能拿到 202321 的資料，造成 follower_count_latest 都是空值。

-- 為了解決上述情境，先算 current_datetime - 7 DAY 的 week_num，並從 big query 中 week_num >= current_datetime - 7 的 kol_followers 之 MAX(week_num)，
-- 這樣就能解決有時候此排程啟動時 202322 week_num 沒資料時，先以 202321 的資料作為 follower_count_latest，亦即若有 202322 就使用，沒有的話就取用 202321 作為
-- follower_count_latest。
SET week_num_current = (
    SELECT
        MAX(week_num)
    FROM renata_rawdata_all.kol_followers
    WHERE week_num >=(
        SELECT
            CASE
                WHEN EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 7 DAY)) = 0
                THEN EXTRACT(year FROM DATETIME_SUB(current_dt, INTERVAL 7 DAY)) *100 + EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 7 DAY)) + 1
                ELSE EXTRACT(year FROM DATETIME_SUB(current_dt, INTERVAL 7 DAY)) *100 + EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 7 DAY))
            END
    )
);

SET week_num_1m = (
    SELECT
        CASE
            WHEN EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 1 MONTH)) = 0
            THEN EXTRACT(year FROM DATETIME_SUB(current_dt, INTERVAL 1 MONTH)) *100 + EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 1 MONTH)) + 1
            ELSE EXTRACT(year FROM DATETIME_SUB(current_dt, INTERVAL 1 MONTH)) *100 + EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 1 MONTH))
        END
);

SET week_num_2m = (
    SELECT
        CASE
            WHEN EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 2 MONTH)) = 0
            THEN EXTRACT(year FROM DATETIME_SUB(current_dt, INTERVAL 2 MONTH)) *100 + EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 2 MONTH)) + 1
            ELSE EXTRACT(year FROM DATETIME_SUB(current_dt, INTERVAL 2 MONTH)) *100 + EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 2 MONTH))
        END
);

SET week_num_3m = (
    SELECT
        CASE
            WHEN EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 3 MONTH)) = 0
            THEN EXTRACT(year FROM DATETIME_SUB(current_dt, INTERVAL 3 MONTH)) *100 + EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 3 MONTH)) + 1
            ELSE EXTRACT(year FROM DATETIME_SUB(current_dt, INTERVAL 3 MONTH)) *100 + EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 3 MONTH))
        END
);

SET week_num_4m = (
    SELECT
        CASE
            WHEN EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 4 MONTH)) = 0
            THEN EXTRACT(year FROM DATETIME_SUB(current_dt, INTERVAL 4 MONTH)) *100 + EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 4 MONTH)) + 1
            ELSE EXTRACT(year FROM DATETIME_SUB(current_dt, INTERVAL 4 MONTH)) *100 + EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 4 MONTH))
        END
);

SET week_num_5m = (
    SELECT
        CASE
            WHEN EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 5 MONTH)) = 0
            THEN EXTRACT(year FROM DATETIME_SUB(current_dt, INTERVAL 5 MONTH)) *100 + EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 5 MONTH)) + 1
            ELSE EXTRACT(year FROM DATETIME_SUB(current_dt, INTERVAL 5 MONTH)) *100 + EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 5 MONTH))
        END
);

SET week_num_6m = (
    SELECT
        CASE
            WHEN EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 6 MONTH)) = 0
            THEN EXTRACT(year FROM DATETIME_SUB(current_dt, INTERVAL 6 MONTH)) *100 + EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 6 MONTH)) + 1
            ELSE EXTRACT(year FROM DATETIME_SUB(current_dt, INTERVAL 6 MONTH)) *100 + EXTRACT(week FROM DATETIME_SUB(current_dt, INTERVAL 6 MONTH))
        END
);

DROP TABLE IF EXISTS renata_etl_temp.group_indicators_follower_info;
CREATE TABLE renata_etl_temp.group_indicators_follower_info AS
(
    SELECT
        kol_id,
        platform,
        platform_user_id,
        MAX(
            CASE
                WHEN week_num = week_num_current
                THEN follower_count_processed
                ELSE NULL
            END
        ) AS follower_count_latest,
        MAX(
            CASE
                WHEN week_num = week_num_1m
                THEN follower_count_processed
                ELSE NULL
            END
        ) AS follower_count_1m,
        MAX(
            CASE
                WHEN week_num = week_num_2m
                THEN follower_count_processed
                ELSE NULL
            END
        ) AS follower_count_2m,
        MAX(
            CASE
                WHEN week_num = week_num_3m
                THEN follower_count_processed
                ELSE NULL
            END
        ) AS follower_count_3m,
        MAX(
            CASE
                WHEN week_num = week_num_4m
                THEN follower_count_processed
                ELSE NULL
            END
        ) AS follower_count_4m,
        MAX(
            CASE
                WHEN week_num = week_num_5m
                THEN follower_count_processed
                ELSE NULL
            END
        ) AS follower_count_5m,
        MAX(
            CASE
                WHEN week_num = week_num_6m
                THEN follower_count_processed
                ELSE NULL
            END
        ) AS follower_count_6m
    FROM renata_rawdata_all.kol_followers
    WHERE (
            week_num = week_num_current 
                OR week_num = week_num_1m 
                OR week_num = week_num_2m
                OR week_num = week_num_3m
                OR week_num = week_num_4m
                OR week_num = week_num_5m
                OR week_num = week_num_6m
        )
    GROUP BY kol_id, platform, platform_user_id
)
;
