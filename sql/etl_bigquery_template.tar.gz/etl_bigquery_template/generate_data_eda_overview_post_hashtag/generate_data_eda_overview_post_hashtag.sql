/*
- Target: 產出 Data EDA Overview - Post, Hashtag 儀表板的資料源
- Source: renata_rawdata_all.latest_facebook_post_hashtag,
          renata_rawdata_all.latest_instagram_post_hashtag,
          renata_rawdata_all.latest_youtube_post_hashtag,
          renata_rawdata_all.kol_followers,
          renata_rawdata_all.kol_url,
          renata_rawdata_all.kol,
          renata_rawdata_all.country,
          renata_rawdata_all.kol_type,
          renata_rawdata_all.ml_generaltag,
          renata_rawdata_all.customized_tag_general_tag_binding,
          renata_rawdata_all.customized_tag,
          renata_rawdata_all.latest_facebook_post,
          renata_rawdata_all.latest_instagram_post,
          renata_rawdata_all.latest_youtube_post
- Description:
    1. renata_etl_temp.eda_overview_hashtag_distinct_info_fb
       取得 facebook post 的不重複 hashtag 資料
    2. renata_etl_temp.eda_overview_hashtag_distinct_info_ig
       取得 instagram post 的不重複 hashtag 資料
    3. renata_etl_temp.eda_overview_hashtag_distinct_info_yt
       取得 youtube post 的不重複 hashtag 資料
    4. renata_ds_report_dashboard.eda_overview_post_hashtag
       取得各平台近一年的貼文加上 hashtag 及 customized tag 資料
*/
DECLARE start_date DATETIME;
DECLARE end_date DATETIME DEFAULT(CURRENT_DATETIME());
DECLARE customized_tag_app_id INT64 DEFAULT({app_id});

SET start_date = (
    SELECT DATETIME_TRUNC(
        DATETIME_SUB(end_date, INTERVAL 12 MONTH),
        MONTH
    )
);

DROP TABLE IF EXISTS `renata_etl_temp.eda_overview_hashtag_distinct_info_fb`;
CREATE TABLE `renata_etl_temp.eda_overview_hashtag_distinct_info_fb` AS (
    SELECT
        platform_post_id,
        STRING_AGG(hashtag, '|' ORDER BY hashtag) AS distinct_hashtag,
        ARRAY_LENGTH(ARRAY_AGG(hashtag)) AS distinct_hashtag_length
    FROM (
        SELECT DISTINCT
            platform_post_id,
            hashtag
        FROM renata_rawdata_all.latest_facebook_post_hashtag, UNNEST(JSON_EXTRACT_STRING_ARRAY(hashtag_content)) AS hashtag
        WHERE post_time BETWEEN TIMESTAMP(start_date) AND TIMESTAMP(end_date) 
    )
    GROUP BY platform_post_id
);

DROP TABLE IF EXISTS `renata_etl_temp.eda_overview_hashtag_distinct_info_ig`;
CREATE TABLE `renata_etl_temp.eda_overview_hashtag_distinct_info_ig` AS (
    SELECT
        platform_post_id,
        STRING_AGG(hashtag, '|' ORDER BY hashtag) AS distinct_hashtag,
        ARRAY_LENGTH(ARRAY_AGG(hashtag)) AS distinct_hashtag_length
    FROM (
        SELECT DISTINCT
            platform_post_id,
            hashtag
        FROM renata_rawdata_all.latest_instagram_post_hashtag, UNNEST(JSON_EXTRACT_STRING_ARRAY(hashtag_content)) AS hashtag
        WHERE post_time BETWEEN TIMESTAMP(start_date) AND TIMESTAMP(end_date) 
    )
    GROUP BY platform_post_id
);


DROP TABLE IF EXISTS `renata_etl_temp.eda_overview_hashtag_distinct_info_yt`;
CREATE TABLE `renata_etl_temp.eda_overview_hashtag_distinct_info_yt` AS (
    SELECT
        platform_post_id,
        STRING_AGG(hashtag, '|' ORDER BY hashtag) AS distinct_hashtag,
        ARRAY_LENGTH(ARRAY_AGG(hashtag)) AS distinct_hashtag_length
    FROM (
        SELECT DISTINCT
            platform_post_id,
            hashtag
        FROM renata_rawdata_all.latest_youtube_post_hashtag, UNNEST(JSON_EXTRACT_STRING_ARRAY(hashtag_content)) AS hashtag
        WHERE post_time BETWEEN TIMESTAMP(start_date) AND TIMESTAMP(end_date) 
    )
    GROUP BY platform_post_id
);

DROP TABLE IF EXISTS `renata_ds_report_dashboard.eda_overview_post_hashtag`;
CREATE TABLE `renata_ds_report_dashboard.eda_overview_post_hashtag` AS (
WITH
    edge_followers AS (
        SELECT
            *
        FROM (
          SELECT 
              kol_id,
              platform_user_id,
              platform,
              follower_count_processed,
              week_num,
              ROW_NUMBER() OVER (PARTITION BY kol_id, platform, platform_user_id ORDER BY week_num DESC) AS row_num_desc,
              ROW_NUMBER() OVER (PARTITION BY kol_id, platform, platform_user_id ORDER BY week_num ASC) AS row_num_asc
          FROM `renata_rawdata_all.kol_followers`
          WHERE follower_count_processed > 0
              AND platform_user_id <> 'undefined'
              AND week_num <= EXTRACT(YEAR FROM end_date) * 100 + EXTRACT(WEEK FROM end_date)
          )
        WHERE (row_num_desc = 1 or row_num_asc=1)
    ),
    generaltag_customized_tag_mapping AS (
        SELECT
            general_tag,
            flat_customized_tag AS customized_tag
        FROM (
            SELECT
                general_tag.general_tag_flat AS general_tag,
                CASE
                    WHEN customized_tag_t1.parent_id IS NOT NULL
                    THEN ARRAY_CONCAT([customized_tag_t2.customized_tag], [customized_tag_t1.customized_tag])
                    ELSE [customized_tag_t1.customized_tag]
                END AS customized_tag
            FROM `renata_rawdata_all.customized_tag_general_tag_binding` AS map
            LEFT JOIN `renata_rawdata_all.general_tag` AS general_tag
                ON map.general_tag_id = general_tag.id
            LEFT JOIN `renata_rawdata_all.customized_tag` AS customized_tag_t1
                ON map.customized_tag_id = customized_tag_t1.id
            LEFT JOIN `renata_rawdata_all.customized_tag` AS customized_tag_t2
                ON customized_tag_t1.parent_id = customized_tag_t2.id
            WHERE app_id = customized_tag_app_id
        ), UNNEST(customized_tag) AS flat_customized_tag
    ),
    post_customized_tag AS (
        SELECT DISTINCT
            post_generaltag.platform,
            post_generaltag.platform_post_id,
            map.customized_tag,
            MAX(post_generaltag.score) AS score,
        FROM (
            SELECT
                platform,
                post_id AS platform_post_id,
                TRIM(JSON_EXTRACT(flat_model_output, '$.prediction'), '"') AS general_tag,
                CAST(TRIM(JSON_EXTRACT(flat_model_output, '$.confidence_score'), '"') AS FLOAT64) AS score
            FROM `renata_rawdata_all.ml_generaltag`, UNNEST(JSON_EXTRACT_ARRAY(model_output)) AS flat_model_output
            WHERE post_time BETWEEN TIMESTAMP(start_date) AND TIMESTAMP(end_date)
        ) AS post_generaltag
        LEFT JOIN generaltag_customized_tag_mapping AS map
            ON post_generaltag.general_tag = map.general_tag
        WHERE customized_tag IS NOT NULL
        GROUP BY platform, platform_post_id, customized_tag
    )

SELECT
    post.*,
    customized_tag.customized_tag AS tag_name,
    ROW_NUMBER() OVER(PARTITION BY post.platform_user_id, post.platform_post_id ORDER BY customized_tag.score DESC) AS tag_rank,
    kol_url.kol_id AS kol_id,
    kol_url.url AS platform_url,
    kol_url.source AS url_source,
    kol_url.status AS url_status,
    kol.source  AS kol_source,
    kol.name AS kol_name,
    country.name_tw AS country,
    lower(kol.gender) AS gender,
    kol_type_info.name AS kol_type,
    desc_followers.follower_count_processed AS follower_count_latest,
    COALESCE(
        followers.follower_count_processed,
        FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY post.platform_user_id
                                                                                        ORDER BY post.post_time
                                                                                        ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
                                                                                    ),
        FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY post.platform_user_id
                                                                                        ORDER BY post.post_time
                                                                                        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                                                                                    ),
        asc_followers.follower_count_processed
    ) AS follower_count_then,
    end_date,
    CURRENT_TIMESTAMP() AS etl_at
FROM (
    SELECT
        platform,
        post.platform_user_id,
        post.platform_post_id,
        DATETIME(post.post_time, 'Asia/Taipei') AS post_time,
        url,
        IFNULL(like_count, 0) AS like_count,
        IFNULL(comment_count, 0) AS comment_count,
        IFNULL(share_count, 0) AS share_count,
        IFNULL(view_count, 0) AS view_count,
        NULL AS play_count,
        ARRAY_TO_STRING(JSON_EXTRACT_STRING_ARRAY(hashtag.hashtag_content), '|') AS hashtag_content,
        ARRAY_LENGTH(JSON_EXTRACT_STRING_ARRAY(hashtag.hashtag_content)) AS hashtag_cnt,
        distinct_hashtag_info.distinct_hashtag,
        distinct_hashtag_info.distinct_hashtag_length,
        CASE
            WHEN is_video IS TRUE
            THEN 1
            ELSE 0
        END AS is_video,
        CASE
            WHEN is_live IS TRUE
            THEN 1
            ELSE 0
        END AS is_live,
        NULL AS is_short,
        CASE
            WHEN is_video IS TRUE
                AND is_live IS TRUE
            THEN 'live_video'
            WHEN is_video IS TRUE
            THEN 'general_video'
            ELSE 'general_post'
        END AS post_type,
        NULL AS is_disable_like
    FROM `renata_rawdata_all.latest_facebook_post` AS post
    LEFT JOIN `renata_rawdata_all.latest_facebook_post_hashtag` AS hashtag
        ON post.platform_post_id = hashtag.platform_post_id
            AND post.platform_user_id = hashtag.platform_user_id
    LEFT JOIN `renata_etl_temp.eda_overview_hashtag_distinct_info_fb` AS distinct_hashtag_info
        ON post.platform_post_id = distinct_hashtag_info.platform_post_id
    WHERE post.post_time BETWEEN TIMESTAMP(start_date) AND TIMESTAMP(end_date)
    
    UNION ALL

    SELECT
        platform,
        post.platform_user_id,
        post.platform_post_id,
        DATETIME(post.post_time, 'Asia/Taipei') AS post_time,
        url,
        IFNULL(like_count, 0) AS like_count,
        IFNULL(comment_count, 0) AS comment_count,
        IFNULL(share_count, 0) AS share_count,
        IFNULL(view_count, 0) AS view_count,
        play_count AS play_count,
        ARRAY_TO_STRING(JSON_EXTRACT_STRING_ARRAY(hashtag.hashtag_content), '|') AS hashtag_content,
        ARRAY_LENGTH(JSON_EXTRACT_STRING_ARRAY(hashtag.hashtag_content)) AS hashtag_cnt,
        distinct_hashtag_info.distinct_hashtag,
        distinct_hashtag_info.distinct_hashtag_length,
        CASE
            WHEN is_video IS TRUE
            THEN 1
            ELSE 0
        END AS is_video,
        CASE
            WHEN is_live IS TRUE
            THEN 1
            ELSE 0
        END AS is_live,
        CASE
            WHEN is_short IS TRUE
            THEN 1
            ELSE 0
        END AS is_short,
        CASE
            WHEN is_video IS TRUE AND is_live IS TRUE
            THEN 'live_video'
            WHEN is_video IS TRUE AND product_type = 'clips'
            THEN 'reels_video'
            WHEN is_video IS TRUE
            THEN 'general_video'
            ELSE 'general_post'
        END post_type,
        CASE
            WHEN is_disable_like IS TRUE
            THEN 1
            ELSE 0
        END AS is_disable_like,
    FROM `renata_rawdata_all.latest_instagram_post` AS post
    LEFT JOIN `renata_rawdata_all.latest_instagram_post_hashtag` AS hashtag
        ON post.platform_post_id = hashtag.platform_post_id
            AND post.platform_user_id = hashtag.platform_user_id
    LEFT JOIN `renata_etl_temp.eda_overview_hashtag_distinct_info_ig` AS distinct_hashtag_info
        ON post.platform_post_id = distinct_hashtag_info.platform_post_id
    WHERE post.post_time BETWEEN TIMESTAMP(start_date) AND TIMESTAMP(end_date)

    UNION ALL

    SELECT
        platform,
        post.platform_user_id,
        post.platform_post_id,
        DATETIME(post.post_time, 'Asia/Taipei') AS post_time,
        url,
        IFNULL(like_count, 0) AS like_count,
        IFNULL(comment_count, 0) AS comment_count,
        IFNULL(share_count, 0) AS share_count,
        IFNULL(view_count, 0) AS view_count,
        NULL AS play_count,
        ARRAY_TO_STRING(JSON_EXTRACT_STRING_ARRAY(hashtag.hashtag_content), '|') AS hashtag_content,
        ARRAY_LENGTH(JSON_EXTRACT_STRING_ARRAY(hashtag.hashtag_content)) AS hashtag_cnt,
        distinct_hashtag_info.distinct_hashtag,
        distinct_hashtag_info.distinct_hashtag_length,
        CASE
            WHEN is_video IS TRUE
            THEN 1
            ELSE 0
        END AS is_video,
        CASE
            WHEN is_live IS TRUE
            THEN 1
            ELSE 0
        END AS is_live,
        CASE
            WHEN is_short IS TRUE
            THEN 1
            ELSE 0
        END AS is_short,
        CASE
            WHEN is_live IS TRUE
            THEN 'live_video'
            WHEN is_short IS TRUE
            THEN 'short_video'
            ELSE 'general_video'
        END post_type,
        NULL AS is_disable_like
    FROM `renata_rawdata_all.latest_youtube_post` AS post
    LEFT JOIN `renata_rawdata_all.latest_youtube_post_hashtag` AS hashtag
        ON post.platform_post_id = hashtag.platform_post_id
            AND post.platform_user_id = hashtag.platform_user_id
    LEFT JOIN `renata_etl_temp.eda_overview_hashtag_distinct_info_yt` AS distinct_hashtag_info
        ON post.platform_post_id = distinct_hashtag_info.platform_post_id
    WHERE post.post_time BETWEEN TIMESTAMP(start_date) AND TIMESTAMP(end_date)
) AS post
LEFT JOIN `renata_rawdata_all.kol_url` AS kol_url
    ON post.platform_user_id = kol_url.platform_user_id
    AND post.platform = kol_url.platform
LEFT JOIN `renata_rawdata_all.kol` AS kol
    ON kol_url.kol_id = kol.id
LEFT JOIN `renata_rawdata_all.country` AS country
    ON kol.country_id = country.id
LEFT JOIN `renata_rawdata_all.kol_type` AS kol_type_info
    ON kol.type_id = kol_type_info.id
LEFT JOIN `renata_rawdata_all.kol_followers` AS followers
    ON post.platform_user_id = followers.platform_user_id
        AND post.platform = followers.platform
        AND kol_url.kol_id = followers.kol_id
        AND EXTRACT(YEAR from post.post_time) * 100 + EXTRACT(WEEK from post.post_time) = followers.week_num
LEFT JOIN edge_followers AS desc_followers
    ON post.platform_user_id = desc_followers.platform_user_id
        AND post.platform = desc_followers.platform
        AND kol_url.kol_id = desc_followers.kol_id
        AND desc_followers.row_num_desc = 1
LEFT JOIN edge_followers AS asc_followers
    ON post.platform_user_id = asc_followers.platform_user_id
        AND post.platform = asc_followers.platform
        AND kol_url.kol_id = asc_followers.kol_id
        AND asc_followers.row_num_asc = 1
LEFT JOIN post_customized_tag AS customized_tag
    ON post.platform = customized_tag.platform
        AND post.platform_post_id = customized_tag.platform_post_id
)
;
