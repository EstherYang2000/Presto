/*
- Target: 產出 Data EDA Overview - KOL 儀表板的資料源
- Source: renata_rawdata_all.kol_fb_stat,
          renata_rawdata_all.kol_ig_stat,
          renata_rawdata_all.kol_yt_stat,
          renata_rawdata_all.kol_url_attribute,
          renata_rawdata_all.kol_url,
          renata_rawdata_all.kol,
          renata_feature.kol_url_type,
          renata_rawdata_all.kol_type,
          renata_rawdata_all.country,
          renata_feature.kol_identification,
          renata_ds_report_dashboard.eda_overview_post_autotag_hashtag,
          renata_rawdata_all.kol_followers
- Description:
    1. renata_ds_report_dashboard.eda_overview_kol_url
       取得 kol_url 表資訊及各帳號近三月/近六月的粉絲數與成長率
    2. renata_ds_report_dashboard.eda_overview_kol
       取得 kol 表資訊
    3. renata_ds_report_dashboard.eda_overview_post_cnt
       取得各帳號近一年的每月發文數
    4. renata_ds_report_dashboard.eda_overview_kol_follower_hist
       取得各帳號 2019 年開始的每週粉絲數
*/
DROP TABLE IF EXISTS `renata_ds_report_dashboard.eda_overview_kol_url`;
CREATE TABLE `renata_ds_report_dashboard.eda_overview_kol_url` AS (
WITH
    stat_info AS (
        SELECT
            kol_id,
            platform,
            platform_user_id,
            current_follower,
            m3_follower,
            m3_follow_growth,
            m3_follow_growth_rate,
            m6_follower,
            m6_follow_growth,
            m6_follow_growth_rate,
            updated_at
        FROM `renata_rawdata_all.kol_fb_stat`
        UNION ALL
        SELECT
            kol_id,
            platform,
            platform_user_id,
            current_follower,
            m3_follower,
            m3_follow_growth,
            m3_follow_growth_rate,
            m6_follower,
            m6_follow_growth,
            m6_follow_growth_rate,
            updated_at
        FROM `renata_rawdata_all.kol_ig_stat`
        UNION ALL
        SELECT
            kol_id,
            platform,
            platform_user_id,
            current_follower,
            m3_follower,
            m3_follow_growth,
            m3_follow_growth_rate,
            m6_follower,
            m6_follow_growth,
            m6_follow_growth_rate,
            updated_at
        FROM `renata_rawdata_all.kol_yt_stat`
    ),
    -- second level label 合併手動更新
    url_type AS (
        SELECT DISTINCT
            COALESCE(attr.platform_user_id, url_type.platform_user_id) AS platform_user_id,
            type.name AS label
        FROM (
            SELECT
                kol_url.platform_user_id,
                IF(label = "", 0, CAST(label AS INT64)) AS label
            FROM `renata_rawdata_all.kol_url_attribute` AS attribute,
                UNNEST(SPLIT(REGEXP_REPLACE(type_id_list, r'[\[\]]', ''), ',')) AS label
            LEFT JOIN `renata_rawdata_all.kol_url` AS kol_url
                ON attribute.kol_url_id = kol_url.id
            WHERE deleted_at IS NULL AND type_id_list != 'null'
        ) AS attr
        FULL JOIN `renata_feature.kol_url_type` AS url_type
            ON url_type.platform_user_id = attr.platform_user_id
                AND url_type.deleted_at IS NULL
        LEFT JOIN `renata_rawdata_all.kol_type` AS type
            ON COALESCE(attr.label, url_type.label) =  type.id
        WHERE type.name IS NOT NULL AND url_type.deleted_at IS NULL
    )
SELECT
    t1.kol_id,
    t2.radar_uuid,
    COUNT(DISTINCT t1.kol_id) OVER (PARTITION BY t2.radar_uuid) AS radar_uuid_cnt,
    t2.name AS kol_name,
    t2.gender,
    DATETIME(t2.deleted_at, 'Asia/Taipei') AS deleted_at,
    t4.name AS kol_type,
    t6.label AS user_id_label,
    t7.label AS iden_label,
    t1.platform,
    t1.platform_user_id,
    t1.kol_platform_name,
    COUNT(DISTINCT t1.platform) OVER (PARTITION BY t1.kol_id) AS kol_platform_cnt,
    t1.url,
    t1.status AS url_status,
    t1.source,
    t1.lookback_period,
    t3.name AS country,
    DATETIME(t1.created_time, 'Asia/Taipei') AS created_time,
    DATETIME(t1.modified_time, 'Asia/Taipei') AS modified_time,
    t5.current_follower,
    t5.m3_follower,
    t5.m3_follow_growth,
    t5.m3_follow_growth_rate,
    t5.m6_follower,
    t5.m6_follow_growth,
    t5.m6_follow_growth_rate,
    DATETIME(t5.updated_at, 'Asia/Taipei') AS updated_at,
    IF(t8.platform_user_id IS NOT NULL, 1, 0) AS has_post,
    CURRENT_TIMESTAMP() AS etl_at
FROM `renata_rawdata_all.kol_url` AS t1
LEFT JOIN `renata_rawdata_all.kol` AS t2
    ON t1.kol_id = t2.id
LEFT JOIN `renata_rawdata_all.country` AS t3
    ON t2.country_id = t3.id
LEFT JOIN `renata_rawdata_all.kol_type` AS t4
    ON t2.type_id = t4.id
LEFT JOIN stat_info AS t5
    ON t1.kol_id = t5.kol_id
        AND t1.platform = t5.platform
        AND t1.platform_user_id = t5.platform_user_id
LEFT JOIN url_type AS t6
    ON t1.platform_user_id = t6.platform_user_id
LEFT JOIN `renata_feature.kol_identification` AS t7
    ON t2.id = t7.kol_id
        AND t7.deleted_at IS NULL
LEFT JOIN (
        SELECT DISTINCT
            platform_user_id
        FROM `renata_ds_report_dashboard.eda_overview_post_autotag_hashtag` 
    ) AS t8
    ON t1.platform_user_id = t8.platform_user_id
)   
;

DROP TABLE IF EXISTS `renata_ds_report_dashboard.eda_overview_kol`;
CREATE TABLE `renata_ds_report_dashboard.eda_overview_kol` AS (
SELECT
    kol.id AS kol_id,
    DATETIME(kol.created_time, 'Asia/Taipei') AS created_time,
    kol.created_by,
    DATETIME(kol.modified_time, 'Asia/Taipei') AS modified_time,
    kol.modified_by,
    kol.source,
    kol.status,
    DATETIME(kol.deleted_at, 'Asia/Taipei') AS deleted_at,
    country.name AS country,
    kol_type_info.name AS kol_type,
    iden.label
FROM `renata_rawdata_all.kol` AS kol
LEFT JOIN `renata_rawdata_all.country` AS country
    ON kol.country_id = country.id
LEFT JOIN `renata_rawdata_all.kol_type` AS kol_type_info
    ON kol.type_id = kol_type_info.id
LEFT JOIN `renata_feature.kol_identification` AS iden
    ON kol.id = iden.kol_id
        AND iden.deleted_at IS NULL
)
;

DROP TABLE IF EXISTS `renata_ds_report_dashboard.eda_overview_post_cnt`;
CREATE TABLE `renata_ds_report_dashboard.eda_overview_post_cnt` AS (
SELECT
    *,
    CURRENT_TIMESTAMP() AS etl_at
FROM (
    SELECT DISTINCT 
        platform_user_id, 
        FORMAT_TIMESTAMP('%Y%m', post_time) AS post_month,
        platform,
        MAX(follower_count_latest) AS follower_count_latest,
        MAX(country) AS country,
        COUNT(DISTINCT platform_post_id) AS post_cnt,
    FROM `renata_ds_report_dashboard.eda_overview_post_autotag_hashtag`
    GROUP BY platform, post_month,  platform_user_id
)
)
;

DROP TABLE IF EXISTS `renata_ds_report_dashboard.eda_overview_kol_follower_hist`;
CREATE TABLE IF NOT EXISTS `renata_ds_report_dashboard.eda_overview_kol_follower_hist`
PARTITION BY mon_date AS (

SELECT 
    followers.kol_id,
    followers.platform,
    followers.mon_date,
    kol.name,
    kol.radar_uuid,
    country.name AS country,
    follower_count,
    CURRENT_TIMESTAMP() AS etl_at
FROM (
    SELECT
        kol_id,
        platform,
        DATE_ADD(
            DATE(CAST(FLOOR(week_num / 100) AS INTEGER), 1, 1),
            INTERVAL (CAST(MOD(week_num, 100) AS INTEGER) - 1) WEEK
        )  AS mon_date,
        follower_count_processed AS follower_count
    FROM `renata_rawdata_all.kol_followers`
    ) AS followers
INNER JOIN `renata_rawdata_all.kol` AS kol
    ON followers.kol_id = kol.id
LEFT JOIN `renata_rawdata_all.country` AS country
    ON kol.country_id = country.id
WHERE followers.mon_date >= '2019-01-01'
)
;
