/*
- Target: 計算各 KOL 的近一個、三個和六格月的各項指標
- Source: renata_etl_temp.group_indicators_follower_info,
          renata_etl_temp.group_indicators_post_info
- Description:
  1. 計算各 KOL 的近一個、三個和六格月的各項指標
  2. 將結果存在 renata_etl_temp.group_indicators_stat
*/
DECLARE current_dt DATETIME DEFAULT(DATE_TRUNC(CURRENT_DATETIME(), month));
DROP TABLE IF EXISTS renata_etl_temp.group_indicators_stat;
CREATE TABLE renata_etl_temp.group_indicators_stat AS
(
    WITH 
        latest_followers AS (
            SELECT 
                follower_info.*,
                CASE WHEN follower_count_latest >= 0 AND follower_count_latest < 10000 THEN "奈米型網紅：1k~10k"
                    WHEN follower_count_latest >= 10000 AND follower_count_latest < 30000 THEN "微型網紅：10k~30k"
                    WHEN follower_count_latest >= 30000 AND follower_count_latest < 50000 THEN "小型網紅：30k~50k"
                    WHEN follower_count_latest >= 50000 AND follower_count_latest < 100000 THEN "中小型網紅：50k~100k"
                    WHEN follower_count_latest >= 100000 AND follower_count_latest < 300000 THEN "中型網紅：100k~300k"
                    WHEN follower_count_latest >= 300000 AND follower_count_latest < 500000 THEN "中大型網紅：300k~500k"
                    WHEN follower_count_latest >= 500000 AND  follower_count_latest < 1000000 THEN "大型網紅：500k~1M"
                    WHEN follower_count_latest >= 1000000 THEN "百萬網紅：>1M"
                ELSE NULL END AS follower_group,
                CASE WHEN follower_count_latest >= 0 AND follower_count_latest < 10000 THEN "nano"
                    WHEN follower_count_latest >= 10000 AND follower_count_latest < 30000 THEN "micro"
                    WHEN follower_count_latest >= 30000 AND follower_count_latest < 50000 THEN "small"
                    WHEN follower_count_latest >= 50000 AND follower_count_latest < 100000 THEN "medium"
                    WHEN follower_count_latest >= 100000 AND follower_count_latest < 300000 THEN "large"
                    WHEN follower_count_latest >= 300000 AND follower_count_latest < 500000 THEN "massive"
                    WHEN follower_count_latest >= 500000 AND  follower_count_latest < 1000000 THEN "huge"
                    WHEN follower_count_latest >= 1000000 THEN "celebrity"
                ELSE NULL END AS follower_group_enum
            FROM renata_etl_temp.group_indicators_follower_info AS follower_info
        ),
    post_stat AS (
        SELECT
            kol_id,
            platform,
            platform_user_id,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH)
                    THEN like_count
                    ELSE NULL
                END
            ) AS like_count_sum_1m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH)
                    THEN like_count
                    ELSE NULL
                END
            ) AS like_count_sum_3m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH)
                    THEN like_count
                    ELSE NULL
                END
            ) AS like_count_sum_6m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH)
                    THEN comment_count
                    ELSE NULL
                END
            ) AS comment_count_sum_1m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH)
                    THEN comment_count
                    ELSE NULL
                END
            ) AS comment_count_sum_3m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH)
                    THEN comment_count
                    ELSE NULL
                END
            ) AS comment_count_sum_6m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH)
                    THEN share_count
                    ELSE NULL
                END
            ) AS share_count_sum_1m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH)
                    THEN share_count
                    ELSE NULL
                END
            ) AS share_count_sum_3m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH)
                    THEN share_count
                    ELSE NULL
                END
            ) AS share_count_sum_6m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH) AND is_short IS TRUE
                    THEN like_count
                    ELSE NULL
                END
            ) AS short_like_count_sum_1m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH) AND is_short IS TRUE
                    THEN like_count
                    ELSE NULL
                END
            ) AS short_like_count_sum_3m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH) AND is_short IS TRUE
                    THEN like_count
                    ELSE NULL
                END
            ) AS short_like_count_sum_6m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH) AND is_short IS TRUE
                    THEN comment_count
                    ELSE NULL
                END
            ) AS short_comment_count_sum_1m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH) AND is_short IS TRUE
                    THEN comment_count
                    ELSE NULL
                END
            ) AS short_comment_count_sum_3m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH) AND is_short IS TRUE
                    THEN comment_count
                    ELSE NULL
                END
            ) AS short_comment_count_sum_6m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH) AND is_short IS TRUE
                    THEN share_count
                    ELSE NULL
                END
            ) AS short_share_count_sum_1m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH) AND is_short IS TRUE
                    THEN share_count
                    ELSE NULL
                END
            ) AS short_share_count_sum_3m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH) AND is_short IS TRUE
                    THEN share_count
                    ELSE NULL
                END
            ) AS short_share_count_sum_6m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH)
                    THEN follower_count
                    ELSE NULL
                END
            ) AS follower_count_sum_1m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH)
                    THEN follower_count
                    ELSE NULL
                END
            ) AS follower_count_sum_3m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH)
                    THEN follower_count
                    ELSE NULL
                END
            ) AS follower_count_sum_6m,
            SUM(
                CASE
                    WHEN is_video IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH)
                    THEN follower_count
                    ELSE NULL
                END
            ) AS video_follower_count_sum_1m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH) AND is_video IS TRUE
                    THEN follower_count
                    ELSE NULL
                END
            ) AS video_follower_count_sum_3m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH) AND is_video IS TRUE
                    THEN follower_count
                    ELSE NULL
                END
            ) AS video_follower_count_sum_6m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH) AND is_short IS TRUE
                    THEN follower_count
                    ELSE NULL
                END
            ) AS short_follower_count_sum_1m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH) AND is_short IS TRUE
                    THEN follower_count
                    ELSE NULL
                END
            ) AS short_follower_count_sum_3m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH) AND is_short IS TRUE
                    THEN follower_count
                    ELSE NULL
                END
            ) AS short_follower_count_sum_6m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH) AND is_video IS TRUE
                    THEN view_count
                    ELSE NULL
                END
            ) AS video_view_count_sum_1m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH) AND is_video IS TRUE
                    THEN view_count
                    ELSE NULL
                END
            ) AS video_view_count_sum_3m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH) AND is_video IS TRUE
                    THEN view_count
                    ELSE NULL
                END
            ) AS video_view_count_sum_6m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH) AND is_short IS TRUE
                    THEN view_count
                    ELSE NULL
                END
            ) AS short_view_count_sum_1m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH) AND is_short IS TRUE
                    THEN view_count
                    ELSE NULL
                END
            ) AS short_view_count_sum_3m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH) AND is_short IS TRUE
                    THEN view_count
                    ELSE NULL
                END
            ) AS short_view_count_sum_6m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH) AND is_short IS TRUE
                    THEN play_count
                    ELSE NULL
                END
            ) AS short_play_count_sum_1m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH) AND is_short IS TRUE
                    THEN play_count
                    ELSE NULL
                END
            ) AS short_play_count_sum_3m,
            SUM(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH) AND is_short IS TRUE
                    THEN play_count
                    ELSE NULL
                END
            ) AS short_play_count_sum_6m,
            COUNT(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH)
                    THEN platform_post_id
                    ELSE NULL
                END
            ) AS post_count_sum_1m,
            COUNT(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH)
                    THEN platform_post_id
                    ELSE NULL
                END
            ) AS post_count_sum_3m,
            COUNT(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH)
                    THEN platform_post_id
                    ELSE NULL
                END
            ) AS post_count_sum_6m,
            COUNT(
                CASE
                    WHEN is_sponsor IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH)
                    THEN platform_post_id
                    ELSE NULL
                END
            ) AS sponsor_post_count_sum_1m,
            COUNT(
                CASE
                    WHEN is_sponsor IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH)
                    THEN platform_post_id
                    ELSE NULL
                END
            ) AS sponsor_post_count_sum_3m,
            COUNT(
                CASE
                    WHEN is_sponsor IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH)
                    THEN platform_post_id
                    ELSE NULL
                END
            ) AS sponsor_post_count_sum_6m,
            COUNT(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH) AND is_video IS TRUE
                    THEN platform_post_id
                    ELSE NULL
                END
            ) AS video_post_count_sum_1m,
            COUNT(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH) AND is_video IS TRUE
                    THEN platform_post_id
                    ELSE NULL
                END
            ) AS video_post_count_sum_3m,
            COUNT(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH) AND is_video IS TRUE
                    THEN platform_post_id
                    ELSE NULL
                END
            ) AS video_post_count_sum_6m,
            COUNT(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 1 MONTH) AND is_short IS TRUE
                    THEN platform_post_id
                    ELSE NULL
                END
            ) AS short_post_count_sum_1m,
            COUNT(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 3 MONTH) AND is_short IS TRUE
                    THEN platform_post_id
                    ELSE NULL
                END
            ) AS short_post_count_sum_3m,
            COUNT(
                CASE
                    WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 6 MONTH) AND is_short IS TRUE
                    THEN platform_post_id
                    ELSE NULL
                END
            ) AS short_post_count_sum_6m
        FROM renata_etl_temp.group_indicators_post_info
        GROUP BY kol_id, platform, platform_user_id
    )
    SELECT 
        post_stat.kol_id,
        post_stat.platform,
        post_stat.platform_user_id,
        latest_followers.follower_group,
        latest_followers.follower_group_enum,
        SAFE_DIVIDE(follower_count_latest - follower_count_1m, follower_count_1m) AS follower_growth_1m,
        SAFE_DIVIDE(follower_count_latest - follower_count_3m, follower_count_3m) AS follower_growth_3m,
        SAFE_DIVIDE(follower_count_latest - follower_count_6m, follower_count_6m) AS follower_growth_6m,
        SAFE_DIVIDE(like_count_sum_1m + comment_count_sum_1m + share_count_sum_1m, follower_count_latest * post_count_sum_1m) AS reaction_rate_1m,
        SAFE_DIVIDE(like_count_sum_3m + comment_count_sum_3m + share_count_sum_3m, follower_count_latest * post_count_sum_3m) AS reaction_rate_3m,
        SAFE_DIVIDE(like_count_sum_6m + comment_count_sum_6m + share_count_sum_6m, follower_count_latest * post_count_sum_6m) AS reaction_rate_6m,
        SAFE_DIVIDE(short_like_count_sum_1m + short_comment_count_sum_1m + short_share_count_sum_1m, follower_count_latest * short_post_count_sum_1m) AS short_reaction_rate_1m,
        SAFE_DIVIDE(short_like_count_sum_3m + short_comment_count_sum_3m + short_share_count_sum_3m, follower_count_latest * short_post_count_sum_3m) AS short_reaction_rate_3m,
        SAFE_DIVIDE(short_like_count_sum_6m + short_comment_count_sum_6m + short_share_count_sum_6m, follower_count_latest * short_post_count_sum_6m) AS short_reaction_rate_6m,
        SAFE_DIVIDE(video_view_count_sum_1m, video_post_count_sum_1m * follower_count_latest) AS video_view_rate_1m,
        SAFE_DIVIDE(video_view_count_sum_3m, video_post_count_sum_1m * follower_count_latest) AS video_view_rate_3m,
        SAFE_DIVIDE(video_view_count_sum_6m, video_post_count_sum_1m * follower_count_latest) AS video_view_rate_6m,
        SAFE_DIVIDE(short_view_count_sum_1m, short_post_count_sum_1m * follower_count_latest) AS short_view_rate_1m,
        SAFE_DIVIDE(short_view_count_sum_3m, short_post_count_sum_3m * follower_count_latest) AS short_view_rate_3m,
        SAFE_DIVIDE(short_view_count_sum_6m, short_post_count_sum_6m * follower_count_latest) AS short_view_rate_6m,
        SAFE_DIVIDE(short_play_count_sum_1m, short_post_count_sum_1m * follower_count_latest) AS short_play_rate_1m,
        SAFE_DIVIDE(short_play_count_sum_3m, short_post_count_sum_3m * follower_count_latest) AS short_play_rate_3m,
        SAFE_DIVIDE(short_play_count_sum_6m, short_post_count_sum_6m * follower_count_latest) AS short_play_rate_6m,
        post_count_sum_1m,
        post_count_sum_3m,
        post_count_sum_6m,
        SAFE_DIVIDE(sponsor_post_count_sum_1m, post_count_sum_1m) AS sponsor_post_ratio_1m,
        SAFE_DIVIDE(sponsor_post_count_sum_3m, post_count_sum_3m) AS sponsor_post_ratio_3m,
        SAFE_DIVIDE(sponsor_post_count_sum_6m, post_count_sum_6m) AS sponsor_post_ratio_6m,
        SAFE_DIVIDE(comment_count_sum_1m, like_count_sum_1m) AS like_comment_ratio_1m,
        SAFE_DIVIDE(comment_count_sum_3m, like_count_sum_3m) AS like_comment_ratio_3m,
        SAFE_DIVIDE(comment_count_sum_6m, like_count_sum_6m) AS like_comment_ratio_6m,
        COUNT(1) OVER (PARTITION BY post_stat.platform, follower_group) AS total_kol_count
    FROM post_stat
    LEFT JOIN latest_followers
        ON post_stat.kol_id = latest_followers.kol_id
            AND post_stat.platform = latest_followers.platform
            AND post_stat.platform_user_id = latest_followers.platform_user_id
)
;