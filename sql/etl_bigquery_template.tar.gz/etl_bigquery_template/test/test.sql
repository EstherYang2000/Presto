select * from ml_feature.potential_kol_fb_tw_hist
where current_week > {start_date}
limit 10