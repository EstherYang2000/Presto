/*
- Target: 產出促購導購儀表板的資料源
- Source: renata_metadata.word_bank,
          renata_metadata.word_category,
          renata_rawdata_all.latest_facebook_post,
          renata_rawdata_all.latest_instagram_post,
          renata_rawdata_all.latest_youtube_post,
          renata_rawdata_all.kol_url_latest,
          renata_rawdata_all.kol,
          renata_rawdata_all.country,
          renata_rawdata_all.kol_type,
          renata_rawdata_all.ml_text_sponsor,
          renata_rawdata_all.kol_followers
- Description:
  產出 2022 年至今的貼文資訊，並標記是否為促購、檔期、電商、url、團購、線下通路關鍵字貼文
*/
DECLARE start_date TIMESTAMP DEFAULT TIMESTAMP('2022-01-01', 'UTC');
DECLARE end_date TIMESTAMP DEFAULT(CURRENT_TIMESTAMP());

DECLARE kw_buy STRING;
DECLARE kw_holiday STRING;
DECLARE kw_ecommerce STRING;
DECLARE kw_url STRING;
DECLARE kw_groupbuy STRING;
DECLARE kw_offlinechannel STRING;


SET end_date = (
    SELECT TIMESTAMP(DATETIME_SUB(DATE_TRUNC(CURRENT_DATETIME(), month), INTERVAL 1 MILLISECOND))
);

SET kw_buy = (
     SELECT STRING_AGG(word, '|') 
     FROM `renata_metadata.word_bank`, UNNEST(category_list) AS category_id
          INNER JOIN `renata_metadata.word_category` AS c
               ON c.category_id = category_id
     WHERE c.category = '促購'
);

SET kw_holiday = (
     SELECT STRING_AGG(word, '|') 
     FROM `renata_metadata.word_bank`, UNNEST(category_list) AS category_id
          INNER JOIN `renata_metadata.word_category` AS c
               ON c.category_id = category_id
     WHERE c.category = '檔期'
);

SET kw_ecommerce = (
     SELECT STRING_AGG(word, '|') 
     FROM `renata_metadata.word_bank`, UNNEST(category_list) AS category_id
          INNER JOIN `renata_metadata.word_category` AS c
               ON c.category_id = category_id
     WHERE c.category = '電商'
);

SET kw_url = (
     SELECT STRING_AGG(word, '|') 
     FROM `renata_metadata.word_bank`, UNNEST(category_list) AS category_id
          INNER JOIN `renata_metadata.word_category` AS c
               ON c.category_id = category_id
     WHERE c.category = 'url'
);

SET kw_groupbuy = (
     SELECT STRING_AGG(word, '|') 
     FROM `renata_metadata.word_bank`, UNNEST(category_list) AS category_id
          INNER JOIN `renata_metadata.word_category` AS c
               ON c.category_id = category_id
     WHERE c.category = '團購'
);

SET kw_offlinechannel = (
     SELECT STRING_AGG(word, '|') 
     FROM `renata_metadata.word_bank`, UNNEST(category_list) AS category_id
          INNER JOIN `renata_metadata.word_category` AS c
               ON c.category_id = category_id
     WHERE c.category = '線下通路'
);

DROP TABLE IF EXISTS `renata_ds_report_dashboard.cmc_kr_tb_promotion_post`;
CREATE TABLE `renata_ds_report_dashboard.cmc_kr_tb_promotion_post` 
     PARTITION BY DATE(post_time)
     CLUSTER BY platform
AS (
    WITH
        edge_followers AS (
            SELECT 
                kol_id,
                platform_user_id,
                platform,
                follower_count_processed,
                week_num,
                ROW_NUMBER() OVER (PARTITION BY kol_id, platform, platform_user_id ORDER BY week_num DESC) AS row_num_desc,
                ROW_NUMBER() OVER (PARTITION BY kol_id, platform, platform_user_id ORDER BY week_num ASC) AS row_num_asc
            FROM `renata_rawdata_all.kol_followers`
            WHERE follower_count_processed > 0
                AND platform_user_id <> 'undefined'
        )
    SELECT
        *,
        platform AS platform_innr,
        (like_count + comment_count + share_count) AS reaction_count,
        CASE
            WHEN follower_count_latest >= 0 AND follower_count_latest < 10000
            THEN "A.<10K"
            WHEN follower_count_latest >= 10000 AND follower_count_latest < 30000
            THEN "B.10K-30K"
            WHEN follower_count_latest >= 30000 AND follower_count_latest < 50000
            THEN "C.30K-50K"
            WHEN follower_count_latest >= 50000 AND follower_count_latest < 100000
            THEN "D.50K-100K"
            WHEN follower_count_latest >= 100000 AND follower_count_latest < 300000
            THEN "E.100K-300K"
            WHEN follower_count_latest >= 300000 AND follower_count_latest < 500000
            THEN "F.300K-500K"
            WHEN follower_count_latest >= 500000 AND  follower_count_latest < 1000000
            THEN "G.500K-1M"
            WHEN follower_count_latest >= 1000000
            THEN "H.1M+"
            ELSE NULL
        END AS follower_range
    FROM (
        SELECT
            kol_url_latest.kol_id AS kol_id,
            post.platform_post_id AS post_id,
            post.url AS post_url,
            post.platform AS platform,
            DATETIME(post.post_time, 'Asia/Taipei') AS post_time,
            CURRENT_DATE('Asia/Taipei') AS data_updated_time, 
            country.name_tw AS country,
            kol.name AS name,
            kol.gender AS gender,
            CASE
                WHEN kol_type_info.name IS NULL
                THEN 'null'
                ELSE kol_type_info.name
            END AS kol_type,
            CONCAT('https://app.kolradar.com/kol/', kol.radar_uuid) AS radar_url,
            desc_followers.follower_count_processed AS follower_count_latest,
            COALESCE(
                followers.follower_count_processed,
                FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY post.platform_user_id
                                                                                                  ORDER BY post.post_time
                                                                                                  ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
                                                                                            ),
                FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY post.platform_user_id
                                                                                                  ORDER BY post.post_time
                                                                                                  ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                                                                                            ),
                asc_followers.follower_count_processed
            ) AS follower_count_then,
            IFNULL(post.like_count, 0) AS like_count,
            IFNULL(post.comment_count, 0) AS comment_count,
            IFNULL(post.share_count, 0) AS share_count,
            IFNULL(post.view_count, 0) AS view_count,
            CASE
                WHEN post.is_video IS TRUE
                THEN 1
                ELSE 0
            END AS is_video,
            CASE
                WHEN post.is_live IS TRUE
                THEN 1
                ELSE 0
            END AS is_live,
            0 AS is_short,
            REGEXP_CONTAINS(post.content, kw_buy) AS is_buy,
            CASE 
                WHEN sponsor.model_output = 'true'
                THEN 1 
                WHEN sponsor.model_output = 'false'
                THEN 0
                ELSE NULL
            END AS is_sponsor,
            REGEXP_CONTAINS(post.content, kw_holiday) AS is_holiday,
            REGEXP_CONTAINS(post.content, kw_ecommerce) AS is_ecommerce,
            REGEXP_CONTAINS(post.content, kw_url) AS is_url,
            REGEXP_CONTAINS(post.content, kw_groupbuy) AS is_groupbuy,
            REGEXP_CONTAINS(post.content, kw_offlinechannel) AS is_offlinechannel
        FROM `renata_rawdata_all.latest_facebook_post` AS post
        LEFT JOIN `renata_rawdata_all.kol_url_latest` AS kol_url_latest
            ON post.platform_user_id = kol_url_latest.platform_user_id
            AND post.platform = kol_url_latest.platform
        LEFT JOIN `renata_rawdata_all.kol` AS kol
            ON kol_url_latest.kol_id = kol.id
        LEFT JOIN `renata_rawdata_all.country` AS country
            ON kol.country_id = country.id
        LEFT JOIN `renata_rawdata_all.kol_type` AS kol_type_info
            ON kol.type_id = kol_type_info.id
        LEFT JOIN `renata_rawdata_all.kol_followers` AS followers
            ON post.platform_user_id = followers.platform_user_id
                AND post.platform = followers.platform
                AND kol_url_latest.kol_id = followers.kol_id
                AND EXTRACT(YEAR from post.post_time) * 100 + EXTRACT(WEEK from post.post_time) = followers.week_num
        LEFT JOIN edge_followers AS desc_followers
            ON post.platform_user_id = desc_followers.platform_user_id
                AND post.platform = desc_followers.platform
                AND kol_url_latest.kol_id = desc_followers.kol_id
                AND desc_followers.row_num_desc = 1
        LEFT JOIN edge_followers AS asc_followers
            ON post.platform_user_id = asc_followers.platform_user_id
                AND post.platform = asc_followers.platform
                AND kol_url_latest.kol_id = asc_followers.kol_id
                AND asc_followers.row_num_asc = 1
        LEFT JOIN `renata_rawdata_all.ml_text_sponsor` AS sponsor
            ON post.platform_post_id = sponsor.post_id
              AND sponsor.platform = 'fb'
        WHERE post.post_time >= start_date
            AND post.content IS NOT NULL
            AND post.content != ''
            AND country.name_tw = '台灣'

        UNION ALL

        SELECT
            kol_url_latest.kol_id AS kol_id,
            post.platform_post_id AS post_id,
            post.url AS post_url,
            post.platform AS platform,
            DATETIME(post.post_time, 'Asia/Taipei') AS post_time,
            CURRENT_DATE('Asia/Taipei') AS data_updated_time, 
            country.name_tw AS country,
            kol.name AS name,
            kol.gender AS gender,
            CASE
                WHEN kol_type_info.name IS NULL
                THEN 'null'
                ELSE kol_type_info.name
            END AS kol_type,
            CONCAT('https://app.kolradar.com/kol/', kol.radar_uuid) AS radar_url,
            desc_followers.follower_count_processed AS follower_count_latest,
            COALESCE(
                followers.follower_count_processed,
                FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY post.platform_user_id
                                                                                                  ORDER BY post.post_time
                                                                                                  ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
                                                                                            ),
                FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY post.platform_user_id
                                                                                                  ORDER BY post.post_time
                                                                                                  ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                                                                                            ),
                asc_followers.follower_count_processed
            ) AS follower_count_then,
            IFNULL(post.like_count, 0) AS like_count,
            IFNULL(post.comment_count, 0) AS comment_count,
            IFNULL(post.share_count, 0) AS share_count,
            IFNULL(post.view_count, 0) AS view_count,
            CASE
                WHEN post.is_video IS TRUE
                THEN 1
                ELSE 0
            END AS is_video,
            CASE
                WHEN post.is_live IS TRUE
                THEN 1
                ELSE 0
            END AS is_live,
            CASE
                WHEN post.is_short IS TRUE
                THEN 1
                ELSE 0
            END AS is_short,
            REGEXP_CONTAINS(post.content, kw_buy) AS is_buy,
            CASE 
                WHEN sponsor.model_output = 'true'
                THEN 1 
                WHEN sponsor.model_output = 'false'
                THEN 0
                ELSE NULL
            END AS is_sponsor,
            REGEXP_CONTAINS(post.content, kw_holiday) AS is_holiday,
            REGEXP_CONTAINS(post.content, kw_ecommerce) AS is_ecommerce,
            REGEXP_CONTAINS(post.content, kw_url) AS is_url,
            REGEXP_CONTAINS(post.content, kw_groupbuy) AS is_groupbuy,
            REGEXP_CONTAINS(post.content, kw_offlinechannel) AS is_offlinechannel
        FROM `renata_rawdata_all.latest_instagram_post` AS post
        LEFT JOIN `renata_rawdata_all.kol_url_latest` AS kol_url_latest
            ON post.platform_user_id = kol_url_latest.platform_user_id
            AND post.platform = kol_url_latest.platform
        LEFT JOIN `renata_rawdata_all.kol` AS kol
            ON kol_url_latest.kol_id = kol.id
        LEFT JOIN `renata_rawdata_all.country` AS country
            ON kol.country_id = country.id
        LEFT JOIN `renata_rawdata_all.kol_type` AS kol_type_info
            ON kol.type_id = kol_type_info.id
        LEFT JOIN `renata_rawdata_all.kol_followers` AS followers
            ON post.platform_user_id = followers.platform_user_id
                AND post.platform = followers.platform
                AND kol_url_latest.kol_id = followers.kol_id
                AND EXTRACT(YEAR from post.post_time) * 100 + EXTRACT(WEEK from post.post_time) = followers.week_num
        LEFT JOIN edge_followers AS desc_followers
            ON post.platform_user_id = desc_followers.platform_user_id
                AND post.platform = desc_followers.platform
                AND kol_url_latest.kol_id = desc_followers.kol_id
                AND desc_followers.row_num_desc = 1
        LEFT JOIN edge_followers AS asc_followers
            ON post.platform_user_id = asc_followers.platform_user_id
                AND post.platform = asc_followers.platform
                AND kol_url_latest.kol_id = asc_followers.kol_id
                AND asc_followers.row_num_asc = 1
        LEFT JOIN `renata_rawdata_all.ml_text_sponsor` AS sponsor
            ON post.platform_post_id = sponsor.post_id
              AND sponsor.platform = 'ig'
        WHERE post.post_time >= start_date
            AND post.content IS NOT NULL
            AND post.content != ''
            AND country.name_tw = '台灣'

        UNION ALL

        SELECT
            kol_url_latest.kol_id AS kol_id,
            post.platform_post_id AS post_id,
            post.url AS post_url,
            post.platform AS platform,
            DATETIME(post.post_time, 'Asia/Taipei') AS post_time,
            CURRENT_DATE('Asia/Taipei') AS data_updated_time, 
            country.name_tw AS country,
            kol.name AS name,
            kol.gender AS gender,
            CASE
                WHEN kol_type_info.name IS NULL
                THEN 'null'
                ELSE kol_type_info.name
            END AS kol_type,
            CONCAT('https://app.kolradar.com/kol/', kol.radar_uuid) AS radar_url,
            desc_followers.follower_count_processed AS follower_count_latest,
            COALESCE(
                followers.follower_count_processed,
                FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY post.platform_user_id
                                                                                                  ORDER BY post.post_time
                                                                                                  ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
                                                                                            ),
                FIRST_VALUE(NULLIF(followers.follower_count_processed, 0) IGNORE NULLS) OVER (PARTITION BY post.platform_user_id
                                                                                                  ORDER BY post.post_time
                                                                                                  ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                                                                                            ),
                asc_followers.follower_count_processed
            ) AS follower_count_then,
            IFNULL(post.like_count, 0) AS like_count,
            IFNULL(post.comment_count, 0) AS comment_count,
            IFNULL(post.share_count, 0) AS share_count,
            IFNULL(post.view_count, 0) AS view_count,
            CASE
                WHEN post.is_video IS TRUE
                THEN 1
                ELSE 0
            END AS is_video,
            CASE
                WHEN post.is_live IS TRUE
                THEN 1
                ELSE 0
            END AS is_live,
            CASE
                WHEN post.is_short IS TRUE
                THEN 1
                ELSE 0
            END AS is_short,
            REGEXP_CONTAINS(post.content, kw_buy) AS is_buy,
            CASE 
                WHEN sponsor.model_output = 'true'
                THEN 1 
                WHEN sponsor.model_output = 'false'
                THEN 0
                ELSE NULL
            END AS is_sponsor,
            REGEXP_CONTAINS(post.content, kw_holiday) AS is_holiday,
            REGEXP_CONTAINS(post.content, kw_ecommerce) AS is_ecommerce,
            REGEXP_CONTAINS(post.content, kw_url) AS is_url,
            REGEXP_CONTAINS(post.content, kw_groupbuy) AS is_groupbuy,
            REGEXP_CONTAINS(post.content, kw_offlinechannel) AS is_offlinechannel
        FROM `renata_rawdata_all.latest_youtube_post` AS post
        LEFT JOIN `renata_rawdata_all.kol_url_latest` AS kol_url_latest
            ON post.platform_user_id = kol_url_latest.platform_user_id
            AND post.platform = kol_url_latest.platform
        LEFT JOIN `renata_rawdata_all.kol` AS kol
            ON kol_url_latest.kol_id = kol.id
        LEFT JOIN `renata_rawdata_all.country` AS country
            ON kol.country_id = country.id
        LEFT JOIN `renata_rawdata_all.kol_type` AS kol_type_info
            ON kol.type_id = kol_type_info.id
        LEFT JOIN `renata_rawdata_all.kol_followers` AS followers
            ON post.platform_user_id = followers.platform_user_id
                AND post.platform = followers.platform
                AND kol_url_latest.kol_id = followers.kol_id
                AND EXTRACT(YEAR from post.post_time) * 100 + EXTRACT(WEEK from post.post_time) = followers.week_num
        LEFT JOIN edge_followers AS desc_followers
            ON post.platform_user_id = desc_followers.platform_user_id
                AND post.platform = desc_followers.platform
                AND kol_url_latest.kol_id = desc_followers.kol_id
                AND desc_followers.row_num_desc = 1
        LEFT JOIN edge_followers AS asc_followers
            ON post.platform_user_id = asc_followers.platform_user_id
                AND post.platform = asc_followers.platform
                AND kol_url_latest.kol_id = asc_followers.kol_id
                AND asc_followers.row_num_asc = 1
        LEFT JOIN `renata_rawdata_all.ml_text_sponsor` AS sponsor
            ON post.platform_post_id = sponsor.post_id
              AND sponsor.platform = 'yt'
        WHERE post.post_time >= start_date
            AND post.content IS NOT NULL
            AND post.content != ''
            AND country.name_tw = '台灣'
    )
    WHERE follower_count_then >= 1000
        AND follower_count_latest >= 1000
)
;
