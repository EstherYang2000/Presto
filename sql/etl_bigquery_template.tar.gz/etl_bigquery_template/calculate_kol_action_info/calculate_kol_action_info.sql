DECLARE etl_at DATETIME;
SET etl_at = DATETIME('{etl_date}');

DROP TABLE IF EXISTS renata_feature.kol_post_text_action_latest;
CREATE TABLE renata_feature.kol_post_text_action_latest AS 
(
    WITH
        posts AS (
        SELECT
            platform,
            platform_user_id,
            platform_post_id
        FROM renata_rawdata_all.latest_facebook_post
        WHERE post_time >= TIMESTAMP(DATETIME_SUB(etl_at, INTERVAL {month_cnt} MONTH))

        UNION ALL

        SELECT
            platform,
            platform_user_id,
            platform_post_id
        FROM renata_rawdata_all.latest_instagram_post
        WHERE post_time >= TIMESTAMP(DATETIME_SUB(etl_at, INTERVAL {month_cnt} MONTH))

        UNION ALL

        SELECT
            platform,
            platform_user_id,
            platform_post_id
        FROM renata_rawdata_all.latest_youtube_post
        WHERE post_time >= TIMESTAMP(DATETIME_SUB(etl_at, INTERVAL {month_cnt} MONTH))
        ),
        all_rawdata AS (
            SELECT
                kol_url.kol_id,
                posts.*,
                action.model_output
            FROM posts
            INNER JOIN renata_rawdata_all.ml_post_text_action AS action
                ON posts.platform_post_id = action.post_id
            LEFT JOIN renata_rawdata_all.kol_url_latest AS kol_url
                ON posts.platform_user_id = kol_url.platform_user_id
            WHERE action.model_output != '[""]'
        ),
        processed_data AS (
            SELECT
                all_rawdata.kol_id,
                all_rawdata.platform,
                all_rawdata.platform_user_id,
                all_rawdata.platform_post_id,
                TRIM(action, '"') AS action
            FROM all_rawdata, UNNEST(JSON_EXTRACT_ARRAY(model_output)) AS action
            WHERE kol_id IS NOT NULL
        ),
        data_ranked AS (
            SELECT
                kol_id,
                action,
                cnt,
                ROW_NUMBER() OVER (PARTITION BY kol_id ORDER BY cnt DESC, action ASC) AS cnt_rank
            FROM (
                SELECT
                    kol_id,
                    action,
                    COUNT(1) AS cnt
                FROM processed_data
                GROUP BY kol_id, action
            )
        )
    SELECT
        kol_id,
        action,
        cnt,
        CURRENT_TIMESTAMP() AS etl_at
    FROM data_ranked
    WHERE cnt_rank <= 100
);
