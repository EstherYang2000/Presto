-- DECLARE current_dt DATETIME DEFAULT(CURRENT_DATETIME());
DECLARE current_dt DATETIME DEFAULT(DATE_TRUNC(CURRENT_DATETIME(), month));

DROP TABLE IF EXISTS renata_etl_temp.kol_scoring_stat;
CREATE TABLE renata_etl_temp.kol_scoring_stat AS
(
    WITH
        post_stat AS (
            SELECT
                kol_id,
                platform,
                platform_user_id,
                MAX(abnormal_ind) AS abnormal_ind,
                COUNT(DISTINCT
                    CASE
                        WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 7 DAY)
                        THEN platform_post_id
                        ELSE NULL
                    END
                ) AS post_sum_1w,
                COUNT(DISTINCT
                    CASE
                        WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 14 DAY)
                        THEN platform_post_id
                        ELSE NULL
                    END
                ) AS post_sum_2w,
                COUNT(DISTINCT
                    CASE
                        WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 30 DAY)
                        THEN platform_post_id
                        ELSE NULL
                    END
                ) AS post_sum_1m,
                COUNT(DISTINCT
                    CASE
                        WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 90 DAY)
                        THEN platform_post_id
                        ELSE NULL
                    END
                ) AS post_sum_3m,

                CASE
                    WHEN (
                        COUNT(DISTINCT
                            CASE
                                WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 30 DAY)
                                THEN platform_post_id
                                ELSE NULL
                            END
                        )
                    ) > 0
                    THEN 1
                    ELSE 0
                END AS post_ind_1m,
                CASE
                    WHEN (
                        COUNT(DISTINCT
                            CASE
                                WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 60 DAY) AND post_date < DATETIME_SUB(current_dt, INTERVAL 30 DAY)
                                THEN platform_post_id
                                ELSE NULL
                            END
                        )
                    ) > 0
                    THEN 1
                    ELSE 0
                END AS post_ind_2m,
                CASE
                    WHEN (
                        COUNT(DISTINCT
                            CASE
                                WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 90 DAY) AND post_date < DATETIME_SUB(current_dt, INTERVAL 60 DAY)
                                THEN platform_post_id
                                ELSE NULL
                            END
                        )
                    ) > 0
                    THEN 1
                    ELSE 0
                END AS post_ind_3m,

                SAFE_DIVIDE(
                    COUNT(DISTINCT
                        CASE
                            WHEN is_video IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 90 DAY)
                            THEN platform_post_id
                            ELSE NULL
                        END
                    ),
                    COUNT(DISTINCT
                        CASE
                            WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 90 DAY)
                            THEN platform_post_id
                            ELSE NULL
                        END
                    )
                ) AS vp_ratio_3m,

                AVG(
                    CASE
                        WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 7 DAY)
                        THEN SAFE_DIVIDE(comment_count + like_count + share_count, follower_count)
                        ELSE NULL
                    END
                ) AS reaction_rate_avg_1w,
                AVG(
                    CASE
                        WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 14 DAY)
                        THEN SAFE_DIVIDE(comment_count + like_count + share_count, follower_count)
                        ELSE NULL
                    END
                ) AS reaction_rate_avg_2w,
                AVG(
                    CASE
                        WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 30 DAY)
                        THEN SAFE_DIVIDE(comment_count + like_count + share_count, follower_count)
                        ELSE NULL
                    END
                ) AS reaction_rate_avg_1m,
                AVG(
                    CASE
                        WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 90 DAY)
                        THEN SAFE_DIVIDE(comment_count + like_count + share_count, follower_count)
                        ELSE NULL
                    END
                ) AS reaction_rate_avg_3m,
                COUNT(DISTINCT
                    CASE
                        WHEN post_date > DATETIME_SUB(current_date, INTERVAL 30 DAY) and is_disable_like
                        THEN platform_post_id
                        ELSE NULL
                    END
                ) AS is_disable_like_sum_1m,
                COUNT(DISTINCT
                    CASE
                        WHEN post_date > DATETIME_SUB(current_date, INTERVAL 90 DAY) and is_disable_like
                        THEN platform_post_id
                        ELSE NULL
                    END
                ) AS is_disable_like_sum_3m,
                AVG(
                    CASE
                        WHEN post_date > DATETIME_SUB(current_date, INTERVAL 30 DAY) and not is_disable_like
                        THEN SAFE_DIVIDE(like_count + comment_count + share_count, follower_count)
                        ELSE NULL
                    END
                ) AS reaction_rate_filter_avg_1m,
                AVG(
                    CASE
                        WHEN post_date > DATETIME_SUB(current_date, INTERVAL 90 DAY) and not is_disable_like
                        THEN SAFE_DIVIDE(like_count + comment_count + share_count, follower_count)
                        ELSE NULL
                    END
                ) AS reaction_rate_filter_avg_3m,

                COUNT(DISTINCT
                    CASE
                        WHEN is_video IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 7 DAY)
                        THEN platform_post_id
                        ELSE NULL
                    END
                ) AS video_post_sum_1w,
                COUNT(DISTINCT
                    CASE
                        WHEN is_video IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 14 DAY)
                        THEN platform_post_id
                        ELSE NULL
                    END
                ) AS video_post_sum_2w,
                COUNT(DISTINCT
                    CASE
                        WHEN is_video IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 30 DAY)
                        THEN platform_post_id
                        ELSE NULL
                    END
                ) AS video_post_sum_1m,
                COUNT(DISTINCT
                    CASE
                        WHEN is_video IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 90 DAY)
                        THEN platform_post_id
                        ELSE NULL
                    END
                ) AS video_post_sum_3m,

                CASE
                    WHEN (
                        COUNT(DISTINCT
                            CASE
                                WHEN is_video IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 30 DAY)
                                THEN platform_post_id
                                ELSE NULL
                            END
                        )
                    ) > 0
                    THEN 1
                    ELSE 0
                END AS video_post_ind_1m,
                CASE
                    WHEN (
                        COUNT(DISTINCT
                            CASE
                                WHEN is_video IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 60 DAY) AND post_date < DATETIME_SUB(current_dt, INTERVAL 30 DAY)
                                THEN platform_post_id
                                ELSE NULL
                            END
                        )
                    ) > 0
                    THEN 1
                    ELSE 0
                END AS video_post_ind_2m,
                CASE
                    WHEN (
                        COUNT(DISTINCT
                            CASE
                                WHEN is_video IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 90 DAY) AND post_date < DATETIME_SUB(current_dt, INTERVAL 60 DAY)
                                THEN platform_post_id
                                ELSE NULL
                            END
                        )
                    ) > 0
                    THEN 1
                    ELSE 0
                END AS video_post_ind_3m,

                AVG(
                    CASE
                        WHEN is_video IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 7 DAY)
                        THEN SAFE_DIVIDE(view_count, follower_count)
                        ELSE NULL
                    END
                ) AS view_rate_avg_1w,
                AVG(
                    CASE
                        WHEN is_video IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 14 DAY)
                        THEN SAFE_DIVIDE(view_count, follower_count)
                        ELSE NULL
                    END
                ) AS view_rate_avg_2w,
                AVG(
                    CASE
                        WHEN is_video IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 30 DAY)
                        THEN SAFE_DIVIDE(view_count, follower_count)
                        ELSE NULL
                    END
                ) AS view_rate_avg_1m,
                AVG(
                    CASE
                        WHEN is_video IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 90 DAY)
                        THEN SAFE_DIVIDE(view_count, follower_count)
                        ELSE NULL
                    END
                ) AS view_rate_avg_3m,

                AVG(
                    CASE
                        WHEN post_date > DATETIME_SUB(current_dt, INTERVAL 30 DAY)
                        THEN SAFE_DIVIDE(comment_count + like_count + share_count, follower_count)
                        ELSE NULL
                    END
                ) AS reaction_rate_1m,
                AVG(
                    CASE
                        WHEN post_date BETWEEN DATETIME_SUB(current_dt, INTERVAL 59 DAY) AND DATETIME_SUB(current_dt, INTERVAL 30 DAY)
                        THEN SAFE_DIVIDE(comment_count + like_count + share_count, follower_count)
                        ELSE NULL
                    END
                ) AS reaction_rate_2m,
                AVG(
                    CASE
                        WHEN post_date BETWEEN DATETIME_SUB(current_dt, INTERVAL 89 DAY) AND DATETIME_SUB(current_dt, INTERVAL 60 DAY)
                        THEN SAFE_DIVIDE(comment_count + like_count + share_count, follower_count)
                        ELSE NULL
                    END
                ) AS reaction_rate_3m,
                AVG(
                    CASE
                        WHEN post_date BETWEEN DATETIME_SUB(current_dt, INTERVAL 119 DAY) AND DATETIME_SUB(current_dt, INTERVAL 90 DAY)
                        THEN SAFE_DIVIDE(comment_count + like_count + share_count, follower_count)
                        ELSE NULL
                    END
                ) AS reaction_rate_4m,
                AVG(
                    CASE
                        WHEN post_date BETWEEN DATETIME_SUB(current_dt, INTERVAL 149 DAY) AND DATETIME_SUB(current_dt, INTERVAL 120 DAY)
                        THEN SAFE_DIVIDE(comment_count + like_count + share_count, follower_count)
                        ELSE NULL
                    END
                ) AS reaction_rate_5m,
                AVG(
                    CASE
                        WHEN post_date BETWEEN DATETIME_SUB(current_dt, INTERVAL 179 DAY) AND DATETIME_SUB(current_dt, INTERVAL 150 DAY)
                        THEN SAFE_DIVIDE(comment_count + like_count + share_count, follower_count)
                        ELSE NULL
                    END
                ) AS reaction_rate_6m,

                AVG(
                    CASE
                        WHEN is_video IS TRUE AND post_date > DATETIME_SUB(current_dt, INTERVAL 30 DAY)
                        THEN SAFE_DIVIDE(view_count, follower_count)
                        ELSE NULL
                    END
                ) AS view_rate_1m,
                AVG(
                    CASE
                        WHEN is_video IS TRUE AND post_date BETWEEN DATETIME_SUB(current_dt, INTERVAL 59 DAY) AND DATETIME_SUB(current_dt, INTERVAL 30 DAY)
                        THEN SAFE_DIVIDE(view_count, follower_count)
                        ELSE NULL
                    END
                ) AS view_rate_2m,
                AVG(
                    CASE
                        WHEN is_video IS TRUE AND post_date BETWEEN DATETIME_SUB(current_dt, INTERVAL 89 DAY) AND DATETIME_SUB(current_dt, INTERVAL 60 DAY)
                        THEN SAFE_DIVIDE(view_count, follower_count)
                        ELSE NULL
                    END
                ) AS view_rate_3m,
                AVG(
                    CASE
                        WHEN is_video IS TRUE AND post_date BETWEEN DATETIME_SUB(current_dt, INTERVAL 119 DAY) AND DATETIME_SUB(current_dt, INTERVAL 90 DAY)
                        THEN SAFE_DIVIDE(view_count, follower_count)
                        ELSE NULL
                    END
                ) AS view_rate_4m,
                AVG(
                    CASE
                        WHEN is_video IS TRUE AND post_date BETWEEN DATETIME_SUB(current_dt, INTERVAL 149 DAY) AND DATETIME_SUB(current_dt, INTERVAL 120 DAY)
                        THEN SAFE_DIVIDE(view_count, follower_count)
                        ELSE NULL
                    END
                ) AS view_rate_5m,
                AVG(
                    CASE
                        WHEN is_video IS TRUE AND post_date BETWEEN DATETIME_SUB(current_dt, INTERVAL 179 DAY) AND DATETIME_SUB(current_dt, INTERVAL 150 DAY)
                        THEN SAFE_DIVIDE(view_count, follower_count)
                        ELSE NULL
                    END
                ) AS view_rate_6m,

            FROM renata_etl_temp.kol_scoring_post_info
            GROUP BY kol_id, platform, platform_user_id
        )
    SELECT
        current_dt AS calculated_base_date,
        post_stat.*,
        follower_info.follower_count_latest,
        follower_info.follower_count_1m,
        follower_info.follower_count_2m,
        follower_info.follower_count_3m,
        follower_info.follower_count_4m,
        follower_info.follower_count_5m,
        follower_info.follower_count_6m,
        country.name_tw AS country,
        kol_type.name AS kol_type
    FROM post_stat
    LEFT JOIN renata_etl_temp.kol_scoring_follower_info AS follower_info
        ON post_stat.kol_id = follower_info.kol_id
            AND post_stat.platform = follower_info.platform
            ANd post_stat.platform_user_id = follower_info.platform_user_id
    LEFT JOIN renata_rawdata_all.kol AS kol
        ON post_stat.kol_id = kol.id
    LEFT JOIN renata_rawdata_all.country AS country
        ON kol.country_id = country.id
    LEFT JOIN renata_rawdata_all.kol_type AS kol_type
        ON kol.type_id = kol_type.id
)
;

